using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Contenedor : MonoBehaviour, IContenedor
{
 	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

	void start(){ }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // Devuelve el contenido y Vacia el contenedor
    virtual public GameObject getContenido(){ return null; }
    virtual public string getTipoContenido(){ return null; }

    // Guarda el nuevo contenido en el contenedor
    virtual public void setContenido( GameObject pContenido ){ }

    virtual public bool isEmpty( ){ return false; }

    virtual public bool isIntercambioValido( Contenedor pContainer ){ return false; }

    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //

    virtual public void deleteContenido(){ }

    virtual public void dropContenido( Transform pUbicacion ) { }

    virtual public void spawnContenido( GameObject pPrefab ){ }

    virtual public void intercambiarContenido( Contenedor pContainer ){ }


    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

}
