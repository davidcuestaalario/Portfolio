using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContenedorStack : Contenedor
{
 	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    [Header("Contenedor")]
    [SerializeField] private int contenedoresMaximos;
    [SerializeField] private List<ContenedorSimple> contenedores;

    // -------------- Constantes -------------- //
	
    private int contenedorActual = -1;

    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

	void start()
    {
        
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // Devuelve el contenido y Vacia el contenedor
    override public GameObject getContenido()
    { 
        // Inicialmente no tenemos ningun contenido
        GameObject asignacion = null;
        // Si no todos los contenedores estan vacios 
        if( !isEmpty() )
        {
            // Asignamos el contenido del contenedor actual
            asignacion = this.contenedores[ this.contenedorActual ].getContenido();
            // Indicamos que este contenedor esta vacio
            this.contenedorActual--;
        }
        // Devolvemos el contenido asignado
        if( asignacion == null ){ Debug.Log("Esta vacio " + this.contenedorActual ); }
        return asignacion; 
    }

    // Guarda el nuevo contenido en el contenedor
    override public void setContenido( GameObject pContenido )
    { 
        // Si no todos los contenedores estan llenos
        if( !isCompleto( ) )
        {
            // Asignamos el contenido al siguiente contenedor
            this.contenedores[ this.contenedorActual+1 ].setContenido( pContenido );
            // Indicamos que este contenedor esta ocupado
            this.contenedorActual++;
        }
    }

    override public bool isEmpty( ){ return ( this.contenedorActual < 0 ); }

    private bool isCompleto( ){ return( this.contenedorActual >= this.contenedoresMaximos-1 ); }

    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //

    override public void deleteContenido()
    {
        // Si no todos los contenedores estan vacios 
        if( !isEmpty() )
        {
            // Asignamos el contenido al contenedor actual
            this.contenedores[ this.contenedorActual ].deleteContenido();
            // Indicamos que este contenedor esta vacio
            this.contenedorActual--;
        }
    }

    override public void dropContenido( Transform pUbicacion )
    {
        // Si no todos los contenedores estan vacios 
        if( !isEmpty() )
        {
            // Asignamos el contenido al contenedor actual
            this.contenedores[ this.contenedorActual ].dropContenido( pUbicacion );
            // Indicamos que este contenedor esta vacio
            this.contenedorActual--;
        }
    }

    override public void spawnContenido( GameObject pPrefab )
    {
        // Si no todos los contenedores estan llenos
        if( !isCompleto( ) )
        {
            // Asignamos el contenido al siguiente contenedor
            this.contenedores[ this.contenedorActual+1 ].spawnContenido( pPrefab );
            // Indicamos que este contenedor esta ocupado
            this.contenedorActual++;
            
        }
    }

    override public void intercambiarContenido( Contenedor pContainer )
    {
        // Almacenamos el ingrediente del otro contenedor 
        GameObject asignacion = pContainer.getContenido();
        // Pasamos el ingrediente de este contenedor al otro
        pContainer.setContenido( this.getContenido() );
        // Guardamos en este contenedor el ingrediente almacenado 
        this.setContenido( asignacion );
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

}
