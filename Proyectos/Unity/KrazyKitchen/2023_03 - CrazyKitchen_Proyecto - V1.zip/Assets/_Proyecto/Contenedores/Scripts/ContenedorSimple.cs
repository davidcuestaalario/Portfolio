using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContenedorSimple : Contenedor
{
 	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    [Header("Contenedor")]
    [SerializeField] private Transform contenedor;
    private GameObject contenido;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

	void start()
    {
        
    }

    public ContenedorSimple( Transform pContenedor ){ this.contenedor = pContenedor; }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // Devuelve el contenido y Vacia el contenedor
    override public GameObject getContenido()
    { 
        // Asignamos el contenido
        GameObject asignacion = this.contenido;
        // Vaciamos el contenedor
        this.contenido = null;
        // Devolvemos el contenido asignado
        return asignacion; 
    }

    // Guarda el nuevo contenido en el contenedor
    override public void setContenido( GameObject pContenido )
    { 
        // Si nos han asignado un ingrediente valido
        if( pContenido != null )
        {
            // Teletransportamos el ingrediente seleccionado al contenedor
            pContenido.transform.position = this.contenedor.position;
            // Vinculamos el contenido al contenedor
            pContenido.transform.SetParent( this.contenedor );
            // Asignamos el Ingrediente
            this.contenido = pContenido;
        }
    }

    override public bool isEmpty( ){ return ( this.contenido == null ); }

    override public bool isIntercambioValido( Contenedor pContainer )
    {
        // Inicialmente asumimos el intercambio sera valido
        bool isValido = true;
        // Un intercambio es valido si hay algo que intercambiar
        if( pContainer.isEmpty() && this.isEmpty() ){ isValido = false; }
        // Devolvemos la comprobacion
        return isValido;
    }
    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //

    override public void deleteContenido()
    {
        // Comprobamos el contendor esta vacio
        if( !isEmpty() )
        {
            // Destruimos el contenido
            Destroy( this.contenido );
            this.contenido = null;
        }
    }

    override public void dropContenido( Transform pUbicacion )
    {
        // Comprobamos si hay algun ingrediente
        if( !isEmpty() )
        {
            // Teletransportamos el contenido a la ubicacion indicada
            this.contenido.transform.position = pUbicacion.position;
            // Desvinculamos el objeto del contenedor
            this.contenido.transform.SetParent( null );
            // Vaciamos el contenedor
            this.contenido = null;
        }
    }

    override public void spawnContenido( GameObject pPrefab )
    {
        // Comprobamos que no haya ningun contenido
        if( isEmpty() )
        {
            // Creamos una nueva instancia
            this.contenido = Instantiate( pPrefab , this.contenedor );
        }
    }

    override public void intercambiarContenido( Contenedor pContainer )
    {
        // Inicialmente asumimos que no se añadira contenido a los platos
        bool isAnadido = false;
        // Obtenemos los contenidos de ambos contenedores
        GameObject pContenido = pContainer.getContenido();
        GameObject contenido = this.getContenido();
        if( pContenido != null ) Debug.Log( pContenido.name );
        if(contenido != null) Debug.Log( contenido.name );
        // Si ambos contenedores tienen contenido
        if( contenido != null && pContenido != null )
        {
            // Intentamos añadir los contenidos a los platos
            if( !isAnadido ){ isAnadido = anadirAlPlato( this , contenido , pContenido ); }
            if( !isAnadido ){ isAnadido = anadirAlPlato( this , pContenido , contenido ); }
        }
        // Si no se ha podido añadir los contenidos a los platos
        if( !isAnadido )
        {
            // Pasamos el ingrediente de este contenedor al otro
            pContainer.setContenido( contenido );
            // Guardamos en este contenedor el ingrediente almacenado 
            this.setContenido( pContenido );
        }
    }

    private bool anadirAlPlato( Contenedor pContenedor , GameObject pPlato , GameObject pContenido )
    {
        // Inicialmente asumimos que no se podra añadir el ingrediente al plato
        bool isAnadido = false;
        // Comprobamos si es un ingrediente de tipo Plato
        if( pPlato.TryGetComponent( out IngredientePlato plato ) )
        {
            // Si el plato no tiene ya incluido el ingrediente 
            if( plato.isValido( pContenido ) )
            {
                // Asignamos el Ingrediente al plato
                plato.setContenido( pContenido );
                // Indicamos que hemos anadido el ingrediente al plato
                isAnadido = true;
                // Devolvemos el plato a su contenedor
                pContenedor.setContenido( pPlato );
            }
        }
        // Devolvemos la comprobacion
        return isAnadido;
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

}
