using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IContenedor
{

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    public GameObject getContenido();
    public void setContenido( GameObject pIngrediente );
    public bool isEmpty();
    public bool isIntercambioValido( Contenedor pContainer );

    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //

    public void dropContenido( Transform pUbicacion );
    public void spawnContenido( GameObject pPrefab );
    public void deleteContenido();
    public void intercambiarContenido( Contenedor pContenedor );


}
