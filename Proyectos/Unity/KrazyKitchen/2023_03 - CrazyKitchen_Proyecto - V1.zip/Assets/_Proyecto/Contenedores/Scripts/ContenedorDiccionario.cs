using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContenedorDiccionario : Contenedor
{
 	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    [Serializable]
    public struct asignacionVisualIngredientes
    {
        public Ingrediente_SO ingrediente;
        public GameObject visual;
    }

    private UISpawnerIngrediente UI;

    // -------------- Constantes -------------- //

    // --------------- Variables -------------- //
	private Dictionary<string, Ingrediente_SO> contenedores = new Dictionary<string, Ingrediente_SO>();
    [SerializeField] private List<asignacionVisualIngredientes> asignaciones;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start()
    {
        // Asignamos la UI
        this.UI = this.gameObject.GetComponent<UISpawnerIngrediente>();
    }
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // Devuelve el contenido y Vacia el contenedor
    override public GameObject getContenido()
    { 
        // Inicialmente no tenemos ningun contenido
        GameObject asignacion = null;
        // Devolvemos el contenido asignado
        return asignacion; 
    }

    // Guarda el nuevo contenido en el contenedor
    override public void setContenido( GameObject pContenido )
    { 
        if( pContenido.TryGetComponent( out Ingrediente iIngrediente ) )
        {
            if( !isIncluido( iIngrediente ) )
            {
                // Eliminamos el contenido
                Destroy(pContenido);
                // Habilitamos el visual del contenido
                this.habilitarVisual( iIngrediente.getIngrediente() );
                // Asignamos el Sprite a la UI
                UI.spawnIcon( iIngrediente.getIngrediente().sprite );
                // Asignamos el contenido al contenedor diccionario
                this.contenedores.Add( iIngrediente.getIngrediente().name , iIngrediente.getIngrediente() );
            }
        }
    }

    override public bool isEmpty( ){ return ( this.contenedores.Count == 0 ); }

    public bool isIncluido( Ingrediente pIngrediente ){ return( this.contenedores.ContainsKey( pIngrediente.getIngrediente().name ) ); }

    public List<Ingrediente_SO> getListaIngredientes()
    {
        // Inicializamos una lista de ingredientes vacia
        List<Ingrediente_SO> listaIngredientes = new List<Ingrediente_SO>();
        // Recorremos los elementos del diccionario
        foreach( KeyValuePair< string , Ingrediente_SO > iContenedor in this.contenedores )
        {
            // Si el contenido tiene un ingrediente
            listaIngredientes.Add( iContenedor.Value );
        }
        // Devolvemos la lista de ingredientes
        return listaIngredientes;
    }



    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //

    override public void deleteContenido(){}

    override public void dropContenido( Transform pUbicacion ){}

    override public void spawnContenido( GameObject pPrefab ){}

    override public void intercambiarContenido( Contenedor pContainer ){ }

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //

    private void habilitarVisual( Ingrediente_SO pIngrediente )
    {
        // Recorremos cada asignacion
        foreach( asignacionVisualIngredientes iAsignacion in this.asignaciones )
        {
            // Si la asignacion coincide activamos su visual
            if( iAsignacion.ingrediente.Equals( pIngrediente ) ){ iAsignacion.visual.SetActive(true); }
        }
    }

}
