using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIProgresPercentage : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    [SerializeField] private Image progresBar;
    [SerializeField] private TMP_Text porcentajeCarga;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Start()
    {
        // Inicialmente la barra de progreso esta oculta
        //setIsVisible( false );
    } 

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    public void setProgreso( float pProgresoActual , int pProgresoMaximo )
    {
        // Calculamos el progreso de la barra
        float progreso = pProgresoActual / pProgresoMaximo;
        this.progresBar.fillAmount = progreso;
        // Actualizamos el porcentaje de carga
        this.porcentajeCarga.text = Mathf.Round( progreso*100 ) + "%";
        // Ocultamos la barra cuando el progreso sea cero o uno
        // if( progreso == 0 || progreso == 1 ){ setIsVisible( false ); }
        // Mostramos la barra para cualquier otro progreso
        //else{ setIsVisible( true ); }
    }

    public void setIsVisible( bool pIsVisible ){ this.gameObject.SetActive( pIsVisible ); }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
	

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
