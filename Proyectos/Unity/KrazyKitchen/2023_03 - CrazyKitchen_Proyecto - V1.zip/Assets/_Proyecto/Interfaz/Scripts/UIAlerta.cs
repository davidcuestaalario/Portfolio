using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIAlerta : MonoBehaviour
{
   // ---------------- Modelo ---------------- //

	[Header("Musica")]
    [SerializeField] private float tiempoEntreAvisos = 0.5f;
    [SerializeField] private Sound sonido;
    [SerializeField] private AudioClip[] listaEfectosWarning;

    [Header("Animacion")]
    private Animator animator;
    [SerializeField] private string tag_animacionAlertar = "Alertar";

    // -------------- Constantes -------------- //

    // --------------- Variables -------------- //

    private float temporizador;

	// --------------- Atributos -------------- //

	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start()
    {
        this.animator = this.gameObject.GetComponent<Animator>();
        this.temporizador = this.tiempoEntreAvisos;
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    void Update()
    {
        // Solo se ejecuta si estamos jugando
        if( KitchenGameManager.Instancia.isPlaying() )
        {
            // Reducimos el tiempo del temporizador
            this.temporizador -= Time.deltaTime;
            // Si el temporizador llega a cero
            if( this.temporizador <= 0 )
            {
                // Reproducimos el sonido de la alerta
                this.sonido.reproducirOneShot( this.listaEfectosWarning );
                // Reiniciamos la animacion
                this.animator.SetTrigger( this.tag_animacionAlertar );
                // Reiniciamos el temporizador
                this.temporizador = this.tiempoEntreAvisos;
            }
        }
    }

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //
	
    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //

}
