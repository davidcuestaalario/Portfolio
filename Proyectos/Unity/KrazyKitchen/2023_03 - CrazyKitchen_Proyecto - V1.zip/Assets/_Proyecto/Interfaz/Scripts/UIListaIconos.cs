using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIListaIconos : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    [SerializeField] private GameObject prefabIcono;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
    
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    // void Start(){}
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    public void addIcono( Sprite pSprite )
    {
        GameObject icono = Instantiate( this.prefabIcono , this.transform );
        icono.GetComponent<Image>().sprite = pSprite;
    }

}
