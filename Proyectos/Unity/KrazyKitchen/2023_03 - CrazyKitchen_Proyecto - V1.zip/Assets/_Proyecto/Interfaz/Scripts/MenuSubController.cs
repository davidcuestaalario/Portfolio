using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuSubController : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //

    [Header("Sub-Menu")]
    [SerializeField] private Button buttonOpen;
    [SerializeField] private Button buttonSelected;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void OnEnable()
    {
        this.buttonSelected?.Select();
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    public Button getButtonOpen( ){ return this.buttonOpen; }

    // ######################################## //
    // ################# Menu ################# //
    // ######################################## //
    private void SwapMenu( bool isActive ){ this.gameObject.SetActive(isActive); }
    public void AbrirSubMenu()
    { 
        this.gameObject?.SetActive(true);
        this.buttonSelected?.Select();
    }
    public void CerrarSubMenu(){ this.gameObject?.SetActive(false); }
    
}
