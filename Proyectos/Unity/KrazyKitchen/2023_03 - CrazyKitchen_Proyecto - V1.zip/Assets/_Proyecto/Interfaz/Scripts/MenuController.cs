using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MenuController : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //

    [Header("Menu")]
    [SerializeField] private Button buttonClose;
    [SerializeField] private bool closeMenu = false;
    [SerializeField] private bool closeSubMenus = false;

    [Header("Sub-Menus")]
    [SerializeField] private List<MenuSubController> listaSubMenus;


    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Awake()
    {
        // Inicializamos los liseners para los botones de este menu
        this.buttonClose?.onClick.AddListener( CerrarMenu );
        // Inicializamos los liseners para los botones
        setSubMenus( );
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    private void setSubMenus( )
    {
        // Para cada Sub-Menu asignado
        foreach( MenuSubController iSubMenu in this.listaSubMenus )
        { 
            iSubMenu.getButtonOpen().onClick.AddListener(() => abrirSubMenu( iSubMenu ));
            //iSubMenu.getButtonClose().onClick.AddListener(() => abrirSubMenu( iSubMenu.gameObject )); 
        }
    }

    // ######################################## //
    // ################# Menu ################# //
    // ######################################## //
    public void SwapMenu( bool isActive ){ this.gameObject.SetActive(isActive); }
    private void AbrirMenu()
    { 
        // Activamos el menu
        this.gameObject.SetActive(true);
        // Activamos el primer subMenu
        this.listaSubMenus.ToArray()[0].AbrirSubMenu();

    }
    private void CerrarMenu()
    { 
        if( this.closeSubMenus ){ desactivarMenus(); }
        if( this.closeMenu ){ this.gameObject.SetActive(false); }
    }

    // ######################################## //
    // ############## Sub-Menus ############### //
    // ######################################## //
    
    // Desactiva todos los menus
    private void desactivarMenus()
    {
        // Cierra todos los subMenus
        foreach( MenuSubController iSubMenu in this.listaSubMenus ){ iSubMenu.CerrarSubMenu(); }
    }

    // Activa un menu concreto
    public void abrirSubMenu( MenuSubController pSubMenu )
    {
        // Cerramos todos los SubMenus
        desactivarMenus();
        // Abrimos el SubMenu indicado
        pSubMenu.AbrirSubMenu();
    }


}
