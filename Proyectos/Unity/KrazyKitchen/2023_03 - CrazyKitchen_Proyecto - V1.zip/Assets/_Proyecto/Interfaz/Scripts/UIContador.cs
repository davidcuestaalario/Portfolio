using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class UIContador : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    [Header("Texto")]
	[SerializeField] private TextMeshProUGUI cuentaAtras;

    [Header("Musica")]
    [SerializeField] private AudioClip sonido;

	[Header("Animacion")]
    private Animator animator;
    [SerializeField] private string tag_animacionContar = "Agitar";

    // -------------- Constantes -------------- //

    // --------------- Variables -------------- //
	
    private int cuenta = 0;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start()
    {
        this.animator = this.gameObject.GetComponent<Animator>();
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    public void setActive( bool pActive ){ this.gameObject.SetActive( pActive ); }
    public void setContador( float pTemporizador )
    { 
        // Convertimos el tiempo a un numero entero
        int cuenta = Mathf.RoundToInt( pTemporizador );
        // Si el numero ha cambiado
        if( this.cuenta != cuenta )
        {
            // Mostramos el nuevo numero 
            this.cuentaAtras.text = cuenta.ToString();
            // Actualizamos la cache
            this.cuenta = cuenta;
            // Si el animador existe ejecutamos la animacion del numero
            this.animator?.SetTrigger( this.tag_animacionContar );
            // Reproducimos el sonido
            SoundManager.Instancia.reproducirOneShot( this.sonido );
        }
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //
	
    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
