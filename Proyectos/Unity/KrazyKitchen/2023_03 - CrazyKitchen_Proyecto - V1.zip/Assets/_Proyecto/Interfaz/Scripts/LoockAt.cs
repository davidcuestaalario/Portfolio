using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoockAt : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    private enum Modo{ Normal , Horizontal , Vertical }

    // -------------- Constantes -------------- //
    [SerializeField] private Modo modo = Modo.Normal;
    [SerializeField] private bool isInverted = false;

    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
	//void Awake(){}
    //void Start(){}
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
	
    //void FixedUpdate(){}
    //void Update(){}
	void LateUpdate()
    {
        Vector3 loockAt = new Vector3( 0 , 0 , 0 );

        // Modo Normal
        if( this.modo.Equals( Modo.Normal ) )
        {
            if( isInverted ){ this.transform.LookAt( 2*this.transform.position - Camera.main.transform.position ); }
            else{ this.transform.LookAt( Camera.main.transform.position ); }
        }

        // Modo Horizontal
        else if( this.modo.Equals( Modo.Normal ) )
        {
            if( isInverted ){ this.transform.forward = Camera.main.transform.forward; }
            else{ this.transform.forward = -Camera.main.transform.forward; }
        }

        // Modo Vertical
        else if( this.modo.Equals( Modo.Normal ) )
        {
            if( isInverted ){ this.transform.up = Camera.main.transform.up; }
            else{ this.transform.up = -Camera.main.transform.up; }
        }

        
    }
	
	// ######################################## //
    // ################ INPUTS ################ //
    // ######################################## //
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
