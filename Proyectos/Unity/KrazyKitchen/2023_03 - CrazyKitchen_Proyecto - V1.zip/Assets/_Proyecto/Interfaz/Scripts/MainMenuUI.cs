using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainMenuUI : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	[SerializeField] private string startScene = "KrazyKitchen";
    [SerializeField] private Button buttonStart;
    [SerializeField] private Button buttonQuit;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	private List<string> kitchenLevels;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Awake()
    {
        // Inicializamos los liseners para los botones
        this.buttonStart.onClick.AddListener( startGame );
        this.buttonStart.Select();
        this.buttonQuit.onClick.AddListener( quitGame );
    }

    void Start()
    {
        this.kitchenLevels = new List<string>();
        this.kitchenLevels.Add("_01");
        this.kitchenLevels.Add("_02");
    }
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    private string getRandomLevel(){ return this.kitchenLevels[ Random.Range( 0 , this.kitchenLevels.Count ) ]; }

    // ######################################## //
    // ############### EVENTOS ################ //
    // ######################################## //
    
    private void startGame()
    { 
        // Seleccionamos el nivel
        string level = "";
        if( SceneManager.GetActiveScene().buildIndex.Equals(0) ){ level = getRandomLevel(); }
        // Cargamos la escena seleccionada
        ManagerEscenas.Instancia.cargarEscenaAsincrona(this.startScene + level ); 
    }
    private void quitGame(){ Application.Quit(); }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
	
	// ######################################## //
    // ################ INPUTS ################ //
    // ######################################## //
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //

}
