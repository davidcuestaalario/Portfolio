using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UICloseMenuPausa : MonoBehaviour
{
	// ---------------- Modelo ---------------- //
    private Button buttonClose;

    // -------------- Constantes -------------- //

    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start()
    { 
        // Capturamos el boton
        this.buttonClose = this.gameObject.GetComponent<Button>();
        // Inicializamos el Listener de Rebind
        buttonClose.onClick.AddListener( closePauseMenu );
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //


    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    private void closePauseMenu(){ KitchenGameManager.Instancia.pause(); }
}
