using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class PlatoUI : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //

	[Header("Interfaz del Plato")]
    [SerializeField] private TextMeshProUGUI nombrePlato;
    [SerializeField] private TextMeshProUGUI puntuacionEntrega;
    [SerializeField] private TextMeshProUGUI puntuacionCaducado;
    [SerializeField] private UIProgresBar progresBar;
    [SerializeField] private UIListaIconos listaIconos;
    private Plato plato;

    [Header("Animacion")]
    private Animator animator;
    [SerializeField] private float tiempoAnimacion = 60f;
    [SerializeField] private string tag_animacionEntregar = "Entregar";
    [SerializeField] private string tag_animacionFallar = "Fallar";

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
    
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Start()
    {
        this.animator = this.gameObject.GetComponent<Animator>();
    }


    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    private void desabilitar(){ this.gameObject.SetActive(false); }

    public Plato getPlato(){ return this.plato; }

    public void setPlato( Plato pPlato )
    {
        // Guardamos el plato
        this.plato = pPlato;
        // Establecemos los titulos y etiquetas del plato 
        this.nombrePlato.text = pPlato.getNombre();
        this.puntuacionEntrega.text = "Entregado: " + pPlato.getPuntuacion() + "$";
        this.puntuacionCaducado.text = "Caducado: -" + pPlato.getPenalizacion() + "$";
        // Establecemos la lista de ingredientes
        foreach( Ingrediente_SO iIngrediente in pPlato.getIngredientes() )
        {
            this.listaIconos.addIcono( iIngrediente.sprite );
        }
    }

    public void actualizarProgreso()
    {
        // Hacemos avanzar la barra de progreso
        this.progresBar.setProgreso( this.plato.getTemporizador() , (int) this.plato.getTiempo() );
    }

    // ######################################## //
    // ############### INTERFAZ ############### //
    // ######################################## //

    public void desactivarUI( )
    {
        // Si el tiempo de entrega ha finalizado, El pedido se ha Fallado 
        if( this.plato.getTemporizador() <= 0 ){ this.animator.SetTrigger( this.tag_animacionFallar ); }
        // En caso contrario, El pedido se ha Entregado
        else{ this.animator.SetTrigger( this.tag_animacionEntregar ); }
    }

    

}
