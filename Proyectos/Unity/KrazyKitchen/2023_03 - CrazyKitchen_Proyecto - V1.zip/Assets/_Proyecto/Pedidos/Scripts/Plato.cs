using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Plato : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    [SerializeField] private Plato_SO plato;

    // -------------- Constantes -------------- //
    private float tiempo;
    private float puntuacion;
    private float penalizacion;

    // --------------- Variables -------------- //
    private float temporizador;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Awake()
    {
        this.tiempo = this.spawnTiempo();
        this.puntuacion = this.spawnPuntuacion();
        this.penalizacion = this.spawnPenalizacion();
        this.temporizador = this.tiempo;
    }
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    public string getNombre(){ return this.plato.nombre; }
    public List<Ingrediente_SO> getIngredientes(){ return this.plato.ingredientes; }
    public float getTemporizador(){ return this.temporizador; }
    public float getTiempo(){ return this.tiempo; }
    public float getPuntuacion(){ return Mathf.Round( this.puntuacion ); }
    public float getPenalizacion(){ return Mathf.Round( this.penalizacion ); }
    public float spawnTiempo(){ return Random.Range( this.plato.tiempo.x , this.plato.tiempo.y ); }
    public float spawnPuntuacion(){ return Random.Range( this.plato.puntuacion.x , this.plato.puntuacion.y ); }
    public float spawnPenalizacion(){ return Random.Range( this.plato.penalizacion.x , this.plato.penalizacion.y ); }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    void Update(){}
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    public bool sonIguales( Plato pPlato )
    { 
        // Inicialmente asumismo que son iguales
        bool sonIguales = true;
        // Comprobamos si tienen todas sus propiedades identicas
        if( !this.plato.nombre.Equals( pPlato.getNombre() ) ){ sonIguales = false; }
        if( !this.plato.tiempo.Equals( pPlato.getTiempo() ) ){ sonIguales = false; }
        if( !this.plato.puntuacion.Equals( pPlato.getPuntuacion() ) ){ sonIguales = false; }
        if( !this.plato.penalizacion.Equals( pPlato.getPenalizacion() ) ){ sonIguales = false; }
        // Devolvemos la comprobacion
        return sonIguales;
    }

    public bool hasSameIngredientes( List<Ingrediente_SO> pListaIngredientes )
    {
        // Inicialmente asumimos que ambas listas de ingredientes son distintas
        bool hasSameIngredientes = false;
        // Comprobamos si ambas listas tienen el mismo numero de ingredientes
        if( pListaIngredientes.Count == this.plato.ingredientes.Count )
        {
            // Inicialmente asumimos que todos los ingredientes del plato estaran en la receta
            bool estaEnPlato = true;
            // Recorremos cada ingrediente del plato
            foreach( Ingrediente_SO iIngredientePlato in this.plato.ingredientes )
            {
                // Inicialmente asumimos que el ingrediente actual del plato no esta en la receta
                bool estaEnReceta = false;
                // Recorremos cada ingrediente de la lista de ingredientes
                foreach( Ingrediente_SO iIngredienteReceta in pListaIngredientes )
                {
                    // Si el ingrediente esta en la lista de ingredientes, Lo indicamos y dejamos de buscar
                    if( iIngredientePlato.Equals( iIngredienteReceta ) ){ estaEnReceta = true; break; }
                }
                // Si un plato no esta en la receta, Lo indicmos y dejamos de buscar
                if( !estaEnReceta ){ estaEnPlato = false; break; }
            }
            // Si todos los ingredientes del plato estan en la receta, Lo indicamos
            if( estaEnPlato ){ hasSameIngredientes = true; }
        }
        // Devolvemos la comprobacion
        return hasSameIngredientes;
    }

    public bool isPlazoEntregaFinalizado( )
    {
        // Inicialmente asumimos que no se ha termiado el tiempo
        bool finalizado = false;
        // Avanzamos el temporizador
        this.temporizador -= Time.deltaTime;
        // Si se termina el tiempo lo indicamos
        if( this.temporizador <= 0 ){ finalizado = true; }
        // Devolvemos la comprobacion
        return finalizado;
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
