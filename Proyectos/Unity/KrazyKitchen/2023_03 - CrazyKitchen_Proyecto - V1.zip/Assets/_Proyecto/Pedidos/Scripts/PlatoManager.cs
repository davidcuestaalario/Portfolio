using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatoManager : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //

    [Header("Pedidos")]
	[SerializeField] private List<GameObject> platos;
    [SerializeField] private int maxPedidos = 4;
    [SerializeField] private float spawnTimer = 4;
    [SerializeField] private int maxPedidosEntregados = 5;
    [SerializeField] private int maxPedidosFalladoss = 5;

    [Header("Ubicaciones")]
    [SerializeField] private Transform ubicacaionPedidos;
    [SerializeField] private Transform ubicacaionEntregados;
    [SerializeField] private Transform ubicacaionFallados;

    [Header("UI")]
    [SerializeField] private PlatoManagerUI UI;
    [SerializeField] private ResumenPedidoManagerUI resumenesPedidos;

    [Header("Musica")]
    [SerializeField] private float volumen = 0.3f;
    [SerializeField] private AudioClip[] listaEfectosNuevo;
    [SerializeField] private AudioClip[] listaEfectosEntregado;
    [SerializeField] private AudioClip[] listaEfectosCaducado;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
    private float temporizador;
	private List<Plato> pedidos;
    private List<Plato> entregados;
    private List<Plato> fallados;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    public static PlatoManager Instancia { get ; private set; }
    void Awake()
    {
        // -------------- Singelton -------------- //
        // Si ya existe una instancia y no es esta
        if( Instancia != null && Instancia != this )
        { 
            // Destruimos la instancia actual
            Destroy( this.gameObject );
        }
        // Si no existe ninguna instancia
        else
        { 
            // Inicializamos una nueva instancia
            Instancia = this;
            // Indicamos que debe conservarse entre escenas
            // DontDestroyOnLoad( this.gameObject );
        }
	}

    void Start()
    {
        this.temporizador = this.spawnTimer;
        this.pedidos = new List<Plato>();
        this.entregados = new List<Plato>();
        this.fallados = new List<Plato>();
    }
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    void Update()
    {
        // Solo si el juego esta en ejecucion
        if( KitchenGameManager.Instancia.isPlaying() )
        {
            anadirPedido( );
            caducarPedidos( );
        }
    }
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    private void anadirPedido( )
    {
        // Avanzamos el temporizador
        this.temporizador -= Time.deltaTime;
        // Si se termina el tiempo 
        if( this.temporizador <= 0 )
        {
            // Reiniciamos el temporizador
            this.temporizador = this.spawnTimer;
            // Si no hemos alcanzado el numero maximo de pedidos
            if( this.pedidos.Count < this.maxPedidos )
            {
                // Seleccionamos un plato aleatorio
                GameObject seleccion = this.platos[ Random.Range( 0 , this.platos.Count ) ];
                // Generamos un nuevo pedido del plato selecionado
                GameObject nuevo = Instantiate( seleccion , this.ubicacaionPedidos );
                this.pedidos.Add( nuevo.GetComponent<Plato>() );
                this.UI.addPlato( nuevo.GetComponent<Plato>() );
                // Reproducimos el efecto de sonido
                SoundManager.Instancia.reproducirOneShot( this.listaEfectosNuevo , this.transform.position , this.volumen );
            }
        }
    }

    private void caducarPedidos()
    {
        // Recorremos todos los pedidos
        for( int i=0 ; i<this.pedidos.Count ; i++ )
        {
            // Comprobamos si el plazo de entrega del pedido ha finalizado
            if( this.pedidos[i].isPlazoEntregaFinalizado() )
            {
                // Anadimos el plato a los fallados
                this.fallados.Add( this.pedidos[i] );
                this.pedidos[i].gameObject.transform.SetParent( this.ubicacaionFallados );
                // Generamos el informe del pedido fallado
                this.resumenesPedidos.fallarPedido( this.pedidos[i] );
                // Eliminamos el plato de los pedidos
                this.UI.eliminarPlato( this.pedidos[i] );
                this.pedidos.RemoveAt(i);
                // Reproducimos el efecto de sonido
                SoundManager.Instancia.reproducirOneShot( this.listaEfectosCaducado , this.transform.position , this.volumen );
                // Comprobamos si este pedido termina el juego
                checkGameEnd();
                // Ya no comprobaremos el resto de pedidos
                i = this.pedidos.Count + 1;
            }
        }
    }

    public bool entregarPlato( List<Ingrediente_SO> pListaIngredientes )
    {
        // Inicialmente asumimos que el plato no se puede entregar
        bool isEntregado = false;
        // Recorremos todos los pedidos
        for( int i=0 ; i<this.pedidos.Count ; i++ )
        {
            // Comprobmos si los ingredientes de cada pedido corresponden con los del plato entregado
            if( this.pedidos[i].hasSameIngredientes( pListaIngredientes ) )
            {
                // Indicamos que el pedido se ha entregado
                isEntregado = true;
                // Anadimos el plato a los entregados
                this.entregados.Add( this.pedidos[i] );
                this.pedidos[i].gameObject.transform.SetParent( this.ubicacaionEntregados );
                // Generamos el informe del pedido entregado
                this.resumenesPedidos.entregarPedido( this.pedidos[i] );
                // Eliminamos el plato de los pedidos
                this.UI.eliminarPlato( this.pedidos[i] );
                this.pedidos.RemoveAt(i);
                // Reproducimos el efecto de sonido
                SoundManager.Instancia.reproducirOneShot( this.listaEfectosEntregado , this.transform.position , this.volumen );
                // Comprobamos si este pedido termina el juego
                checkGameEnd();
                // Ya no comprobaremos el resto de pedidos
                i = this.pedidos.Count + 1;
            }
        }
        return isEntregado;
    }

    private void checkGameEnd()
    {
        // Si alcanzamos el numero de platos entregados o fallados
        if( this.entregados.Count >= this.maxPedidosEntregados || this.fallados.Count >= this.maxPedidosFalladoss )
        {
            // Termina el juego
            KitchenGameManager.Instancia.endGame();
        }
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
