using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ResumenPedidoManagerUI : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    [SerializeField] private TextMeshProUGUI titulo;
    [SerializeField] private GameObject prefabResumenPedido;
    private Dictionary<string, ResumenPedidoUI> listaPedidos = new Dictionary<string, ResumenPedidoUI>();

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    // void Start(){}
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	public void setTitulo( string pTitulo ){ this.titulo.text = pTitulo; }
    
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    public void entregarPedido( Plato pPlato )
    {
        // Si la lista de pedidos no contiene el plato, Creamos uno nuevo
        if( !this.listaPedidos.ContainsKey( pPlato.getNombre() ) ){ crearResumenPedido( pPlato ); }
        // Identificamos el pedido indicado
        if( this.listaPedidos.TryGetValue( pPlato.getNombre() , out ResumenPedidoUI iResumenPedido ) )
        {
            // Entregamos el pedido
            iResumenPedido.entregarPedido( Mathf.RoundToInt( pPlato.getPuntuacion() ) );
        }
        // Si el plato no esta incluido
        else{ Debug.Log("Fallo inesperado al generar el resumen de un pedido"); }
    }

    public void fallarPedido( Plato pPlato )
    {
        // Si la lista de pedidos no contiene el plato, Creamos uno nuevo
        if( !this.listaPedidos.ContainsKey( pPlato.getNombre() ) ){ crearResumenPedido( pPlato ); }
        // Identificamos el pedido indicado
        if( this.listaPedidos.TryGetValue( pPlato.getNombre() , out ResumenPedidoUI iResumenPedido ) )
        {
            // Entregamos el pedido
            iResumenPedido.fallarPedido( Mathf.RoundToInt( pPlato.getPuntuacion() ) );
        }
        // Si el plato no esta incluido
        else{ Debug.Log("Fallo inesperado al generar el resumen de un pedido"); }
    }

    private void crearResumenPedido( Plato pPlato )
    {
        // Instanciamos un nuevo pedido
        GameObject resumenPedidoGameObject = Instantiate( this.prefabResumenPedido , this.transform );
        ResumenPedidoUI resumenPedido = resumenPedidoGameObject.GetComponent<ResumenPedidoUI>();
        // Inicializamos el pedido
        resumenPedido.setResumenPedido( pPlato.getNombre() );
        // Lo añadimos a la lista
        this.listaPedidos.Add( pPlato.getNombre() , resumenPedido );
    }

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //
	
    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
