using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatoManagerUI : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    [SerializeField] private GameObject prefabMenuPlato;

    private List<GameObject> listaPlatos;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Start()
    {
        this.listaPlatos = new List<GameObject>();
    }
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    public void addPlato( Plato pPlato )
    {
        // Creamos un nuevo plato UI
        GameObject plato = Instantiate( this.prefabMenuPlato , this.transform );
        // Asignamos sus propiedades
        plato.GetComponent<PlatoUI>().setPlato( pPlato );
        // Lo almacenamos en una lista
        this.listaPlatos.Add(plato);
    }

    public void eliminarPlato( Plato pPlato )
    {
        // Recorremos todos los pedidos
        for( int i=0 ; i<this.listaPlatos.Count ; i++ )
        {
            // Identificamos el plato
            PlatoUI plato = this.listaPlatos[i].GetComponent<PlatoUI>();
            // Si se trata del plato que buscamos
            if( plato.getPlato().Equals( pPlato ) )
            { 
                // Eliminamos el plato
                plato.desactivarUI();
                this.listaPlatos.RemoveAt( i );
            }
        }
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
    
    void Update()
    {
        actualizarProgresos( );
    }

    public void actualizarProgresos( )
    {
        // Recorremos cada plato UI comprobando si
        foreach( GameObject iPlato in this.listaPlatos )
        {
            // Identificamos el plato que buscamos
            iPlato.GetComponent<PlatoUI>().actualizarProgreso();
        }
    }

}
