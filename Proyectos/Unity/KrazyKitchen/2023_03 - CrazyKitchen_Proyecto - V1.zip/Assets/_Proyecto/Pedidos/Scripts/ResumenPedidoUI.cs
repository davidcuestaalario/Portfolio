using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ResumenPedidoUI : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    [SerializeField] private TextMeshProUGUI tituloPedidoGUI;
    [SerializeField] private TextMeshProUGUI numeroEntregadosGUI;
    [SerializeField] private TextMeshProUGUI precioEntregadosGUI;
    [SerializeField] private TextMeshProUGUI numeroFalladosGUI;
    [SerializeField] private TextMeshProUGUI precioFalladosGUI;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	private string tituloPedido;
    private int numeroEntregados;
    private int precioEntregados;
    private int numeroFallados;
    private int precioFallados;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    // void Start(){}
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	public void setResumenPedido( string pTituloPedido )
    { 
        // Establecemos el Titulo del pedido
        this.tituloPedido = pTituloPedido;
        this.tituloPedidoGUI.text = pTituloPedido;
        // Establecemos el numero de pedidos entregados
        this.numeroEntregados = 0;
        this.numeroEntregadosGUI.text = " - ";
        // Establecemos el precio de los pedidos entregados
        this.precioEntregados = 0;
        this.precioEntregadosGUI.text = " - " + "$";
        // Establecemos el numero de pedidos fallados
        this.numeroFallados = 0;
        this.numeroFalladosGUI.text =  " - ";
        // Establecemos el precio de los pedidos fallados
        this.precioFallados = 0;
        this.precioFalladosGUI.text = " - " + "$"; 
    }

    public void setResumenPedido( string pTituloPedido , int pNumeroEntregados , int pPrecioEntregados , int pNumeroFallados , int pPrecioFallados )
    {
        // Establecemos el Titulo del pedido
        this.tituloPedido = pTituloPedido;
        this.tituloPedidoGUI.text = pTituloPedido;
        // Establecemos el numero de pedidos entregados
        this.numeroEntregados = pNumeroEntregados;
        this.numeroEntregadosGUI.text = pNumeroEntregados.ToString();
        // Establecemos el precio de los pedidos entregados
        this.precioEntregados = pPrecioEntregados;
        this.precioEntregadosGUI.text = pPrecioEntregados + "$";
        // Establecemos el numero de pedidos fallados
        this.numeroFallados = pNumeroFallados;
        this.numeroFalladosGUI.text = pNumeroFallados.ToString();
        // Establecemos el precio de los pedidos fallados
        this.precioFallados = pPrecioFallados;
        this.precioFalladosGUI.text = pPrecioFallados + "$";   
    }


    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    public void entregarPedido( int pPrecioEntregados )
    {
        // Establecemos el numero de pedidos fallados
        this.numeroEntregados++;
        this.numeroEntregadosGUI.text = this.numeroEntregados.ToString();
        // Establecemos el precio de los pedidos fallados
        this.precioEntregados += pPrecioEntregados;
        this.precioEntregadosGUI.text = this.precioEntregados + "$";   
    }

    public void fallarPedido( int pPrecioFallados )
    {
        // Establecemos el numero de pedidos fallados
        this.numeroFallados++;
        this.numeroFalladosGUI.text = this.numeroFallados.ToString();
        // Establecemos el precio de los pedidos fallados
        this.precioFallados += pPrecioFallados;
        this.precioFalladosGUI.text = this.precioFallados + "$";   
    }

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //
	
    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
