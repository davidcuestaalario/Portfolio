using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[CreateAssetMenu()]
public class Plato_SO : ScriptableObject
{
    public string nombre;
    public List<Ingrediente_SO> ingredientes;
    public Vector2 tiempo;
    public Vector2 puntuacion;
    public Vector2 penalizacion;
}
