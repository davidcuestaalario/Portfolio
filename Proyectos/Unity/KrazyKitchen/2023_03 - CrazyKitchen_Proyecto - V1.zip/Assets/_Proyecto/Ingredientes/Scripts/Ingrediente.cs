using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ingrediente : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //

    [Header("Ingrediente")]
    [SerializeField] private GameObject visualSelected;
    [SerializeField] private Ingrediente_SO ingrediente;

	// ----------------- Flags ---------------- //
    
    // Permite saber si el ingrediente esta selecionado
    private bool isSelected = false;

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    public Ingrediente_SO getIngrediente(){ return this.ingrediente; }


    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    public void seleccionar( bool pSeleccionado )
    {
        this.visualSelected.SetActive( pSeleccionado );
    }

    public Ingrediente cocinar( ListaRecetas pListaRecetas )
    {
        // Inicialmente el ingrediente no esta cocinado
        Ingrediente ouput = this;
        // Buscamos si existe alguna receta cocinable
        Receta receta = pListaRecetas.getRecetaCocinable( this );
        // Si obtenemos alguna receta valida obtenemos su resultado
        if( receta != null ){ ouput = receta.getOuput().prefab.GetComponent<Ingrediente>(); }
        // Devolvemos el resultado de la cocina
        return ouput;
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //

    public void printIngredienteInfo(){ Debug.Log( this.ingrediente.nombre ); }

}
