using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[CreateAssetMenu()]
public class Ingrediente_SO : ScriptableObject
{
    public GameObject prefab;
    public Sprite sprite;
    public string nombre;
}
