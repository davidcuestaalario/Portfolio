using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IngredientePlato : MonoBehaviour, IContenedor
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	protected ContenedorDiccionario contenedor;
    [SerializeField] private List<Ingrediente_SO> ingredientesValidos;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Start()
    {
        // Asignamos el contenedor
        this.contenedor = this.gameObject.GetComponent<ContenedorDiccionario>();
    }
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	    
    // -------------- Contenedor -------------- //
	public GameObject getContenido(){ return this.contenedor.getContenido(); }
    public void setContenido( GameObject pIngrediente ){ this.contenedor.setContenido( pIngrediente ); }
    public bool isEmpty(){ return this.contenedor.isEmpty(); }
    public bool isValido( GameObject pIngrediente )
    { 
        // Inicialmente asumimos que no es valido
        bool isValido = false;
        // Comprobamos si se trata de un ingrediente
        if( pIngrediente.TryGetComponent( out Ingrediente iIngrediente ) )
        {
            // Comprobamos si el ingrediente ya existe
            bool isIncluido = this.contenedor.isIncluido( iIngrediente );
            // Comprobamos si el ingrediente esta incluido en la lista de ingredientes permitidos
            bool isInPermitidos = this.isInPermitidos( iIngrediente.getIngrediente().name );
            // Un ingrediente sera valido si esta en los permitidos y no esta ya incluido
            isValido = !isIncluido && isInPermitidos;
        }
        // Devolvemos la comprobacion
        return isValido; 
    }

    public bool isIntercambioValido( Contenedor pContenedor ){ return this.contenedor.isIntercambioValido( pContenedor ); }

    private bool isInPermitidos( string nombre )
    { 
        // Inicialmente asumimos que el ingrediente no esta incluido en la lista de ingredientes validos
        bool isInPermitidos = false;
        // Para cada ingrediente valido comprobamos si nuestro ingrediente coincide
        foreach( Ingrediente_SO iIngrediente in this.ingredientesValidos )
        {
            if( iIngrediente.name.Equals(nombre) ){ isInPermitidos = true; }
        }
        // Devolvemos la comprobacion
        return isInPermitidos;
    }

    public List<Ingrediente_SO> getListaIngredientes(){ return this.contenedor.getListaIngredientes(); }
    
    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
	
    //void Update(){}

    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //
    public void intercambiarContenido( Contenedor pContenedor ){ this.contenedor.intercambiarContenido( pContenedor ); }
    public void dropContenido( Transform pUbicacion ){ this.contenedor.dropContenido( pUbicacion ); }
    public void spawnContenido( GameObject pPrefab ){ this.contenedor.spawnContenido( pPrefab ); }
    public void deleteContenido(){ this.contenedor.deleteContenido(); }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
