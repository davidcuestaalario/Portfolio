using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IngredienteIcono : MonoBehaviour
{
    // ---------------- Modelo ---------------- //
	[SerializeField] private SpriteRenderer renderizador;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    public void setIcono( Sprite pSprite ){ this.renderizador.sprite = pSprite; }

}
