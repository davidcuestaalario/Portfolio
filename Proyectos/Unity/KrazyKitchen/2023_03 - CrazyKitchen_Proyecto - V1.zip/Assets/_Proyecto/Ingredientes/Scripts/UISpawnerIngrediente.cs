using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UISpawnerIngrediente : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	[SerializeField] private Canvas UI;
    [SerializeField] private GameObject iconPrefab;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    //void Start(){}
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
	
    //void Update(){}
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    public void spawnIcon( Sprite pSprite )
    {
        // Creamos una nueva instancia del icono
        GameObject icono = Instantiate( this.iconPrefab , this.UI.transform );
        // Sustituimos el Sprite
        icono.GetComponent<IngredienteIcono>().setIcono( pSprite );
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
