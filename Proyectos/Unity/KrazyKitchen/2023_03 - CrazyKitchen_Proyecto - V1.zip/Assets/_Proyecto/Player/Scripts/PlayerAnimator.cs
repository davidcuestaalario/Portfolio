using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAnimator : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //
    [Header("Modelo")]
    private Animator animator;
    [SerializeField] private PlayerMovimiento player;

    // -------------- Constantes -------------- //
    private const string ISWALKING = "IsWalking";

    // ----------------- Flags ---------------- //
    private bool isWalking = false;
    
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start()
    {
        this.animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        this.isWalking =  this.player.getIsWalking();
        this.animator.SetBool( ISWALKING ,  this.isWalking );
    }
}
