using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovimiento : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //

    // --------------- Variables -------------- //
    private Vector3 direccionMovimiento = new Vector3( 0 , 0 , 0 );
    private float temporizador;

    // --------------- Atributos -------------- //

    // Velocidad del perosnaje
    [Header("Velocidad")]
    [SerializeField] private float aVelocidadMovimiento = 5f;
    [SerializeField] private float aVelocidadRotacion = 5f;

    // Dimensiones del perosnaje
    [Header("Colisiones")]
    [SerializeField] private LayerMask colisionableLayers;
    [SerializeField] private float aColisionDistancia = 0.5f;
    [SerializeField] private float aColisionAltura = 2f;
    [SerializeField] private float aColisionRadio = 0.3f;

    [Header("Musica")]
    [SerializeField] private Sound sonido;
    [SerializeField] private float tiempoEntrePisadas;
    [SerializeField] private AudioClip[] listaEfectosMovimiento;
    

	// ----------------- Flags ---------------- //
    
    // Permite saber si el jugador se esta moviendo
    private bool isWalking = false;
    // Permite saber si el jugador tiene permitido moverse
    //private bool canMove = true;

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start(){ this.temporizador = this.tiempoEntrePisadas; }

	// ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    public bool getIsWalking(){ return isWalking; }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    void Update()
    {
        // Solo cuando estemos jugando o en la preparacion
        if( KitchenGameManager.Instancia.isPlaying() || KitchenGameManager.Instancia.isStarting() )
        {
            getInputs();
            controlarMovimiento();
        }
    }

    // ######################################## //
    // ################ INPUTS ################ //
    // ######################################## //

    private void getInputs()
    {
        getInputDireccionMovimiento( );

    }

    private void getInputDireccionMovimiento() 
    {
        // Inicialmente suponemos que no se registra ningun movimiento
        this.isWalking = false;
        // Inicialmente suponemos que el movimiento esta permitido
        //this.canMove = true;
        // Capturamos el imput del movimiento
        Vector2 movimiento = InputManager.Instancia.getMovimientoHorizontal_NormalizedVector();
        // Lo convertimos en un Vector3
        this.direccionMovimiento = new Vector3( -movimiento.y , 0 , -movimiento.x );
        //  Comprobamos si se ha ejecutado algun movimiento
        if( this.direccionMovimiento.magnitude > 0 ){ this.isWalking = true; }
    }

    // ######################################## //
    // ####### MOVIMIENTO DEL PERSONAJE ####### //
    // ######################################## //

    private void controlarMovimiento() 
    {
        colisionDetector( );
        ejecutarMovimiento( );
        ejecutarEfectosSonido( );
    }

    private void colisionDetector()
    {
        // Comprobamos si la colision se produce en el eje X o Z 
        Vector3 movimientoX = new Vector3( this.direccionMovimiento.x , 0 , 0 );
        Vector3 movimientoZ = new Vector3( 0 , 0 , this.direccionMovimiento.z );
        // Si se produce la colision, Censuramos el movimiento en esa direccion
        if( colisionDetector( movimientoX ) ){ this.direccionMovimiento.x = 0; }
        if( colisionDetector( movimientoZ ) ){ this.direccionMovimiento.z = 0; }
    }

    private bool colisionDetector( Vector3 pMovimiento )
    {
        // Calculamos el centro de una esfera situada a la mitad de la altura del personaje
        Vector3 centro = this.transform.position + Vector3.up * this.aColisionAltura/2;
        // Definimos el origen de un rayo que se lanza desde el centro de la esfera en la direccion establecida como parametro
        Ray ray = new Ray( centro , pMovimiento );
        // Lanzamos el rayo con forma esferica y devolvemos la comprobacion si se prodece una colision
        return Physics.SphereCast( ray , this.aColisionRadio , this.aColisionDistancia , colisionableLayers );
    }

    private void ejecutarMovimiento() 
    {
        // Desplazamos al personaje en la direccion del movimiento
        this.transform.position += direccionMovimiento * this.aVelocidadMovimiento * Time.deltaTime;
        // Rotamos al personaje en la direccion del Movimiento utilizando suavizado
        this.transform.forward = Vector3.Slerp( this.transform.forward , this.direccionMovimiento , Time.deltaTime * this.aVelocidadRotacion );
    }

    private void ejecutarEfectosSonido() 
    {
        if( this.isWalking )
        {
            // Calculamos cuanto tiempo ha pasado desde la ultima pisada
            this.temporizador -= Time.deltaTime;
            // Si ya ha pasado tiempo suficiente desde la ultima pisada
            if( this.temporizador <= 0 )
            {
                // Reiniciamos el temporizador
                this.temporizador = this.tiempoEntrePisadas;
                // Reproducimos el efecto de sonido
                this.sonido.reproducirOneShot( this.listaEfectosMovimiento );
            }

        }
    }

	// ######################################## //
    // ################ GIZMOS ################ //
    // ######################################## //
	
	private void OnDrawGizmos()
    {
        // ----- MOVIMIENTO DEL PERSONAJE ----- //
        Vector3 centro = this.transform.position + Vector3.up * this.aColisionAltura/2 + this.direccionMovimiento;
        Gizmos.DrawSphere( centro , this.aColisionRadio );
    }
}
