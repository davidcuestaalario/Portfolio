using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMueble : MonoBehaviour, IContenedor
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //
    [Header("Modelo")]
    private Contenedor manos;

    // --------------- Variables -------------- //
    private Vector3 direccionInteraccion = new Vector3( 0 , 0 , 0 );
    private IMueble selectedMueble;
    private GameObject selectedIngrediente;

    // --------------- Atributos -------------- //
    [Header("Interacciones")]
    [SerializeField] private float aInteraccionDistancia = 2f;

    [Header("Musica")]
    [SerializeField] private Sound sonido;
    [SerializeField] private AudioClip[] listaEfectosDrop;
    [SerializeField] private AudioClip[] listaEfectosPick;

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Start()
    {
        // Suscripcion al evento de interactuar del InputSystem
        InputManager.Instancia.onInteractuarAction += onInteractuarAction;
        // Suscripcion al evento de actuar del InputSystem
        InputManager.Instancia.onActuarAction += onActuarAction;
        // Asignamos el contenedor
        this.manos = this.gameObject.GetComponent<Contenedor>();
    }

    private void OnDestroy()
    {
        // Suscripcion al evento de interactuar del InputSystem
        InputManager.Instancia.onInteractuarAction -= onInteractuarAction;
        // Suscripcion al evento de actuar del InputSystem
        InputManager.Instancia.onActuarAction -= onActuarAction;
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    // -------------- Contenedor -------------- //
	public GameObject getContenido(){ return this.manos.getContenido(); }
    public void setContenido( GameObject pIngrediente ){ this.manos.setContenido( pIngrediente ); }
    public bool isEmpty(){ return this.manos.isEmpty(); }
    public bool isIntercambioValido( Contenedor pContenedor ){ return this.manos.isIntercambioValido( pContenedor ); }

    // ######################################## //
    // ############### EVENTOS ################ //
    // ######################################## //
    
    // Suscrito al evento de Interactuar del InputSystem
    private void onInteractuarAction( object pSender , System.EventArgs pArgs ) 
    {
        // Solo si estamos jugando
        if( KitchenGameManager.Instancia.isPlaying() )
        {
            // Si hay un ingrediente seleccionado
            if( this.selectedIngrediente != null )
            {
                // Si las manos del personaje estan vacias recojemos el objeto
                if( this.manos.isEmpty() )
                {
                    // Asignamos el Ingrediente a las manos del jugador
                    this.manos.setContenido( this.selectedIngrediente );
                    // Deselecionamos el ingrediente
                    this.selectedIngrediente?.GetComponent<Ingrediente>()?.seleccionar( false );
                    this.selectedIngrediente = null;
                    // Reproducimos el efecto de sonido
                    this.sonido.reproducirOneShot( this.listaEfectosDrop );
                }
            }
            // Si hay un mueble seleccionado
            else if( this.selectedMueble != null )
            {
                // Si el intercambio va a ser valido
                if( this.selectedMueble.isIntercambioValido( this.manos )  )
                {
                    // Intercambiamos los ingredientes
                    this.selectedMueble.interactuar( this );
                    // Reproducimos el efecto de sonido
                    this.sonido.reproducirOneShot( this.listaEfectosPick );
                }
            }
            // Si no hay nada seleccionado
            else
            {
                // Deasasignamos el ingrediente de las manos del jugador
                this.manos.dropContenido( this.transform );
                // Reproducimos el efecto de sonido
                this.sonido.reproducirOneShot( this.listaEfectosDrop );
            }
        }
 
    }

    // Suscrito al evento de Actuar del InputSystem
    private void onActuarAction( object pSender , System.EventArgs pArgs ) 
    {
        // Solo si estamos jugando
        if( KitchenGameManager.Instancia.isPlaying() )
        {
            // Si hay un mueble seleccionado, Ejecuta su accion
            if( this.selectedMueble != null ){ this.selectedMueble.actuar( this ); }
        }
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    void Update()
    {
        // Solo si el juego esta en ejecucion
        if( KitchenGameManager.Instancia.isPlaying() )
        {
            getInputs();
            ejecutarInteraciones();
        }
    }
    
    // ######################################## //
    // ################ INPUTS ################ //
    // ######################################## //

    private void getInputs()
    {
        getInputDireccionInteraccion( );

    }

    private void getInputDireccionInteraccion()
    {
        // Capturamos el imput del movimiento
       Vector2 movimiento = InputManager.Instancia.getMovimientoHorizontal_NormalizedVector();
        // Lo convertimos en un Vector3
        Vector3 direccionMovimiento = new Vector3( -movimiento.y , 0 , -movimiento.x );
        // La direccion de la interaccion es la direccion de movimiento excepto si esta es cero
        if( direccionMovimiento != Vector3.zero ){ this.direccionInteraccion = direccionMovimiento; }
    }

    // ######################################## //
    // ##### INTERACCIONES DEL PERSONAJE ###### //
    // ######################################## //
    private void ejecutarInteraciones() 
    {
        objectDetector();
    }

    private void objectDetector()
    {
        // Deseleccionamos el mueble
        this.selectedMueble?.seleccionar( false );
        this.selectedMueble = null;
        // Deseleccionamos el ingrediente
        this.selectedIngrediente?.GetComponent<Ingrediente>()?.seleccionar( false );
        this.selectedIngrediente = null;
        // Creamos un nuevo rayo desde la base del personaje actual en la direccion del movimiento
	    Ray ray = new Ray( this.transform.position , this.direccionInteraccion );
        // Lanzamos el RayCast a una distancia maxima
        if( Physics.Raycast( ray , out RaycastHit hit , this.aInteraccionDistancia ) )
        {
            // Dibujamos el RayCast
            Debug.DrawRay( ray.origin , ray.direction * this.aInteraccionDistancia , Color.red , Time.deltaTime );
            // Si es un componente que implementa la clase mueble lo seleccionamos
            if( hit.transform.TryGetComponent( out IMueble mueble ) )
            { 
                // Seleccionamos la mesa
                mueble.seleccionar( true );
                this.selectedMueble = mueble; 
            }
            // Si es un componente que implementa la clase Ingrediente y el perosnaje no lleva ningun ingrediente en las manos
            if( hit.transform.TryGetComponent( out Ingrediente ingrediente ) && this.manos.isEmpty() )
            { 
                // Seleccionamos el Ingrediente
                ingrediente.seleccionar( true );
                this.selectedIngrediente = ingrediente.gameObject;
            }
        }
    }

    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //

    public void intercambiarContenido( Contenedor pContenedor ){ this.manos.intercambiarContenido( pContenedor ); }
    public void dropContenido( Transform pUbicacion ){ this.manos.dropContenido( pUbicacion ); }
    public void spawnContenido( GameObject pPrefab ){ this.manos.spawnContenido( pPrefab ); }
    public void deleteContenido(){ this.manos.deleteContenido(); }

}
