using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class InputManager : MonoBehaviour
{

	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    private PlayerImputActions imputActions;

    // -------------- Constantes -------------- //
    public enum InputControl{ Left , Right , Forward , Backward , Interactuar , Actuar , Pausa }
    private string label_imputSaves = "label_ImputSaves";

    // ---------------- Eventos --------------- //
    // Evento para notificar la interaccion 
	public event EventHandler onInteractuarAction;
	public event EventHandler onActuarAction;
    public event EventHandler onPausaAction;

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    public static InputManager Instancia { get ; private set; }
    void Awake()
    {
        // -------------- Singelton -------------- //
        // Si ya existe una instancia y no es esta
        if( Instancia != null && Instancia != this )
        { 
            // Destruimos la instancia actual
            Destroy( this.gameObject );
        }
        // Si no existe ninguna instancia
        else
        { 
            // Inicializamos una nueva instancia
            Instancia = this;
            // Indicamos que debe conservarse entre escenas
            DontDestroyOnLoad( this.gameObject );
        }
		// ----------- Inicializaciones ---------- //
        // Definimos una nueva instancia del Input system
        this.imputActions = new PlayerImputActions();
        // Cargamos la configuracion de teclas desde un JSon
        if( PlayerPrefs.HasKey( this.label_imputSaves ) )
        {
            string jSonInputs = PlayerPrefs.GetString( this.label_imputSaves );
            this.imputActions.LoadBindingOverridesFromJson( jSonInputs );
        }
        // Activamos los imputs definidos como Player
        this.imputActions.Player.Enable();
        this.imputActions.Player.Interactuar.performed += interactuar_performed;
        this.imputActions.Player.Actuar.performed += actuar_performed;
        this.imputActions.Player.Pausa.performed += pausa_performed;

	}
    
	private void OnDestroy()
	{ 
		// Limpiamos la memoria del inputManager para evitar StackOverflow
		this.imputActions.Dispose();
	}

    // ######################################## //
    // ##### INTERACCIONES DEL PERSONAJE ###### //
    // ######################################## //

    private void interactuar_performed( UnityEngine.InputSystem.InputAction.CallbackContext pContext )
    {
        // Notificamos que se ha pulsado la tecla para interactuar
        onInteractuarAction?.Invoke( this , EventArgs.Empty );
    } 

    private void actuar_performed( UnityEngine.InputSystem.InputAction.CallbackContext pContext )
    {
        // Notificamos que se ha pulsado la tecla para interactuar
        onActuarAction?.Invoke( this , EventArgs.Empty );
    } 

    private void pausa_performed( UnityEngine.InputSystem.InputAction.CallbackContext pContext )
    {
        // Notificamos que se ha pulsado la tecla para interactuar
        onPausaAction?.Invoke( this , EventArgs.Empty );
    } 

    // ######################################## //
    // ####### MOVIMIENTO DEL PERSONAJE ####### //
    // ######################################## //

    public Vector3 getMovimientoHorizontal_NormalizedVector() 
    {
        // Inicializamos el vector de movimiento como un vector vacio
        Vector2 movimientoWASD = this.imputActions.Player.Move.ReadValue<Vector2>();
        // Normalizamos el Vector de movimiento
        movimientoWASD.Normalize();
        // Devolvemos el vector de movimiento
        return movimientoWASD;
    }

    public Vector3 getMovimientoHorizontal_NormalizedVector_oldSystem() 
    {
        // Inicializamos el vector de movimiento como un vector vacio
        Vector3 movimientoWASD = new Vector3( 0 , 0 , 0 );
        // Tomamos los imputs del movimiento con las teclas WASD
        if( Input.GetKey( KeyCode.W ) ){ movimientoWASD.z = 1; }
        if( Input.GetKey( KeyCode.S ) ){ movimientoWASD.z = -1; }
        if( Input.GetKey( KeyCode.D ) ){ movimientoWASD.x = 1; }
        if( Input.GetKey( KeyCode.A ) ){ movimientoWASD.x = -1; }
        // Normalizamos el Vector de movimiento
        movimientoWASD.Normalize();
        // Devolvemos el vector de movimiento
        return movimientoWASD;
    }

    // ######################################## //
    // ############### REBINDING ############## //
    // ######################################## //

    public string getControlAsignado( InputControl pControl )
    {
        // Inicializamos el control asignado como vacio
        string controlAsignado = "";
        // Identificamos el control indicado y obtenemos la tecla asignada
        switch( pControl )
        {
            default:
            case InputControl.Interactuar: controlAsignado = this.imputActions.Player.Interactuar.bindings[0].ToDisplayString(); break;
            case InputControl.Actuar: controlAsignado = this.imputActions.Player.Actuar.bindings[0].ToDisplayString(); break;
            case InputControl.Pausa: controlAsignado = this.imputActions.Player.Pausa.bindings[0].ToDisplayString(); break;
            case InputControl.Left: controlAsignado = this.imputActions.Player.Move.bindings[1].ToDisplayString(); break;
            case InputControl.Right: controlAsignado = this.imputActions.Player.Move.bindings[2].ToDisplayString(); break;
            case InputControl.Forward: controlAsignado = this.imputActions.Player.Move.bindings[3].ToDisplayString(); break;
            case InputControl.Backward: controlAsignado = this.imputActions.Player.Move.bindings[4].ToDisplayString(); break;
        }
        // Devolvemos el control asignado
        return controlAsignado;
    }

    public void setControlAsignado( InputControl pControl , Action pOnRebindComplete )
    {
        // Desabilitamos el mapa de controles: No se puede modificar un control que se esta utilizando
        this.imputActions.Player.Disable();
        // Identificamos el control indicado
        switch( pControl )
        {
            default:
            case InputControl.Interactuar: onRebindStart( this.imputActions.Player.Interactuar , 0 , pOnRebindComplete ); break;
            case InputControl.Actuar: onRebindStart( this.imputActions.Player.Actuar , 0 , pOnRebindComplete ); break;
            case InputControl.Pausa: onRebindStart( this.imputActions.Player.Pausa , 0 , pOnRebindComplete ); break;
            case InputControl.Left: onRebindStart( this.imputActions.Player.Move , 1 , pOnRebindComplete ); break;
            case InputControl.Right: onRebindStart( this.imputActions.Player.Move , 2 , pOnRebindComplete ); break;
            case InputControl.Forward: onRebindStart( this.imputActions.Player.Move , 3 , pOnRebindComplete ); break;
            case InputControl.Backward: onRebindStart( this.imputActions.Player.Move , 4 , pOnRebindComplete ); break;
        }
    }

    private void onRebindStart( InputAction pInputAction , int pIndex , Action pOnRebindComplete )
    {
        // Lanzamos el evento para cambiar de tecla 
        // Suscribimos una funcion al evento de finalizacion
        // Reiniciamos el proceso de captura de Inputs
        pInputAction.PerformInteractiveRebinding( pIndex ).OnComplete( callback => onRebindComplete( callback , pOnRebindComplete ) ).Start();
    }

    private void onRebindComplete( InputActionRebindingExtensions.RebindingOperation callback , Action pOnRebindComplete )
    {
        // Reiniciamos el proceso de Rebinding
        callback.Dispose();
        // Volvemos a habilitar el mapa de controles
        this.imputActions.Player.Enable();
        // Guardamos la nueva configuracion de teclas
        string jSonInputs = this.imputActions.SaveBindingOverridesAsJson();
        PlayerPrefs.SetString( this.label_imputSaves , jSonInputs );
        PlayerPrefs.Save();
        // Ejecutamos las acciones 
        pOnRebindComplete();
    }

}
