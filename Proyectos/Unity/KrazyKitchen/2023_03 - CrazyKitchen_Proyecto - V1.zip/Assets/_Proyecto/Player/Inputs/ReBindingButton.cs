using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ReBindingButton : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    [Header("Externos")]
    [SerializeField] private GameObject panelInformacion;

    [Header("Internos")]
    [SerializeField] private TextMeshProUGUI textoTecla;
    private Button buttonRebind;
    [SerializeField] private InputManager.InputControl control;

    // -------------- Constantes -------------- //
    private string label_rebind = "_";

    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Start()
    { 
        // Capturamos el boton
        this.buttonRebind = this.gameObject.GetComponent<Button>();
        // Inicializamos el Listener de Rebind
        buttonRebind.onClick.AddListener( setControlAsignado );
        // Obtenemos del InputManager el control asignado actualmente
        this.textoTecla.text = InputManager.Instancia.getControlAsignado( this.control );
        // Desabilitamos el panel de informacion
        this.panelInformacion.SetActive(false);
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //


    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    private void setControlAsignado()
    {
        // Ajustamos la interfaz mientras esperamos a que se complete el Rebind
        this.textoTecla.text = this.label_rebind;
        this.panelInformacion.SetActive(true);
        // Informamos al input manager del cambio de tecla indicando las acciones que se tienen que ejecutar cuando finalice
        InputManager.Instancia.setControlAsignado( this.control , onRebindComplete );

    }

    private void onRebindComplete()
    {
        // Obtenemos del InputManager el control asignado actualmente
        this.textoTecla.text = InputManager.Instancia.getControlAsignado( this.control );
        // Desabilitamos el panel de informacion
        this.panelInformacion.SetActive(false);
    }
}
