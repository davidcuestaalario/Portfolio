using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KitchenGameManager : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	private enum GameState{ loading , starting , playing , pause , ending }
    private GameState gameState;

    [Header("UI")]
    [SerializeField] private GameObject pauseMenu;
    [SerializeField] private GameObject endingMenu;

    // -------------- Constantes -------------- //
    [Header("Temporizador")]
    [SerializeField] private UIContador temporizadorUI;
    [SerializeField] private float tiempoPreparacion = 10f;
    [SerializeField] private float tiempoFinalizacion = 5f;

    // --------------- Variables -------------- //
	
    private float temporizador;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
	public static KitchenGameManager Instancia { get ; private set; }
    void Awake()
    {
        // -------------- Singelton -------------- //
        // Si ya existe una instancia y no es esta
        if( Instancia != null && Instancia != this )
        { 
            // Destruimos la instancia actual
            Destroy( this.gameObject );
        }
        // Si no existe ninguna instancia
        else
        { 
            // Inicializamos una nueva instancia
            Instancia = this;
            // Indicamos que debe conservarse entre escenas
            // DontDestroyOnLoad( this.gameObject );
        }
        // --------------- Variables -------------- //
        // Arrancamos la maquina de estados por el estado inicial
        this.gameState = GameState.loading;
	}

    void Start()
    {
        // Suscripcion al evento de pausa del InputSystem
        InputManager.Instancia.onPausaAction += onPausaAction;
    }
	
    private void OnDestroy()
    {
        // Suscripcion al evento de pausa del InputSystem
        InputManager.Instancia.onPausaAction -= onPausaAction;
    }
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    public bool isPlaying( ){ return this.gameState.Equals( GameState.playing ); }
    public bool isStarting( ){ return this.gameState.Equals( GameState.starting ); }
    public bool isPause( ){ return this.gameState.Equals( GameState.pause ); }
    private void setGameState( GameState pGameState ){ this.gameState = pGameState; }

    // ######################################## //
    // ############### EVENTOS ################ //
    // ######################################## //
    
    // Suscrito al evento de Interactuar del InputSystem
    private void onPausaAction( object pSender , System.EventArgs pArgs ){ pause( ); }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    void Update()
    {
        stateMachine( );
    }

    // ######################################## //
    // ################ TIMER ################# //
    // ######################################## //

    private bool isTemporizadorOver( )
    {
        // Inicialmente asumimos que el temporizador no ha terminado
        bool isOver = false;
        // Si el temporizador ha terminado, 
        if( this.temporizador <= 0 )
        { 
            // Desactivamos el temporizador
            this.temporizadorUI.setActive( false );
            // Indicamos el temporizador ha terminado
            isOver = true;
        }
        // Si el temporizador no ha terminado, 
        else
        { 
            // Avanzamos la cuenta atras
            this.temporizador -= Time.deltaTime;
            this.temporizadorUI.setContador( this.temporizador );
        }
        // Devolvemos la comprobacion
        return isOver;
    }

    // ######################################## //
    // ############ STATE MACHINE ############# //
    // ######################################## //

    private void stateMachine( )
    {
        switch( this.gameState )
        {
            case GameState.loading: stateLoading(); break;
            case GameState.starting: stateStarting(); break;
            case GameState.playing: statePlaying(); break;
            case GameState.pause: statePause(); break;
            case GameState.ending: stateEnding(); break;
        }
    }

    // ---------------- Loading --------------- //
    private void stateLoading( )
    {
        // Preparamos el temporizador
        this.temporizador = this.tiempoPreparacion;
        this.temporizadorUI.setContador( this.temporizador );
        this.temporizadorUI.setActive( true );
        // Cambiamos al estado de inicio
        setGameState( GameState.starting );
    }

    // --------------- Starting --------------- //
    
    private void stateStarting( )
    {
        // Cuando termine la cuenta atras canbiamos al estado del Juego
        if( isTemporizadorOver() ){ setGameState( GameState.playing ); }
    }

    // ---------------- Playing --------------- //

    private void statePlaying( )
    {
        // NADA
    }

    // ----------------- Pause ---------------- //
    public void pause( )
    {
        // Si estamos jugando, 
        if( isPlaying() )
        { 
            // Cambiamos al estado de pause
            setGameState( GameState.pause );
            // Mostramos el menu de pausa
            this.pauseMenu.SetActive( true );
            this.endingMenu.SetActive( true );
        }
        // Si estamos en pausa
        else if( isPause() )
        { 
            // Cambiamos al estado de playing
            setGameState( GameState.playing );
            // Ocultamos el menu de pausa
            this.pauseMenu.SetActive( false );
            this.endingMenu.SetActive( false );
        }
    }
    private void statePause( )
    {

    }

    // ---------------- Ending ---------------- //
    public void endGame( )
    {
        // Si estamos jugando, 
        if( isPlaying() )
        { 
            // Cambiamos al estado de finalizacion
            setGameState( GameState.ending );
            // Mostramos la pantalla de estadisticas
            this.endingMenu.SetActive( true );
            this.pauseMenu.SetActive( true );
            // Preparamos el temporizador
            this.temporizador = this.tiempoFinalizacion;
        }
    }
    private void stateEnding( )
    {
        //if( Input.anyKey && isTemporizadorOver() ){ Debug.Log( "Volvemos al menu Inicial" ); }
    }

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //
	
    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
