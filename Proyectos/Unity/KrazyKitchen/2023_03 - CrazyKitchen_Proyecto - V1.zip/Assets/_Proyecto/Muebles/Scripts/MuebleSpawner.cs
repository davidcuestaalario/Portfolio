using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuebleSpawner : Mueble
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //
    [Header("Modelo")]
	[SerializeField] private SpriteRenderer caratula;
    [SerializeField] private Animator animator;

    // -------------- Constantes -------------- //
	[Header("Spawn")]
    [SerializeField] private Ingrediente ingrediente;
    private string tag_animacion = "OpenClose";
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    override protected void inicializaciones( )
    {
        this.caratula.sprite = ingrediente.getIngrediente().sprite;
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    public override bool isIntercambioValido( Contenedor pContenedor )
    {
        // Para el mueble Spawner un intercambio es valido si las manos del personaje estan vacias
        return pContenedor.isEmpty();
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //public void Update(){}

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    override public void interactuar( PlayerMueble pPlayer )
    {
        // Si el mueble esta vacio y las manos del jugador tambien
        if( base.contenedor.isEmpty() && pPlayer.isEmpty() )
        {
            // Instanciamos el ingrediente
            base.contenedor.spawnContenido( this.ingrediente.getIngrediente().prefab );
            // Le damos el ingrediente al jugador
            pPlayer.intercambiarContenido( base.contenedor );
            // Ejecutamos la animacion
            animator.SetBool( this.tag_animacion , true );
        }
        
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //


}
