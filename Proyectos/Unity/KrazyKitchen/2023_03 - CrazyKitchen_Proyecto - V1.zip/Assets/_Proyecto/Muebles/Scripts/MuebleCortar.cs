using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuebleCortar : Mueble
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
    
    // ---------------- Modelo ---------------- //
    private ListaRecetas recetasDisponibles;

    [SerializeField] private UIProgresBar progresBar;
    [SerializeField] private Animator animador;
    
    [Header("Musica")]
    [SerializeField] private Sound sonido;
    [SerializeField] private AudioClip[] listaEfectos;

    // -------------- Constantes -------------- //
    private string tag_animacion = "Cut";

    // --------------- Variables -------------- //
	private int cortesActuales = 0;

	// --------------- Atributos -------------- //
	
	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    override protected void inicializaciones( )
    {
        this.recetasDisponibles = this.gameObject.GetComponent<ListaRecetas>();
        // Reniciamos el numero de cortes
        this.cortesActuales = 0;
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //public void Update(){}

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    override public void interactuar( PlayerMueble pPlayer )
    {
        // Intercambiamos el contenido entre el Player y el Mueble
        pPlayer.intercambiarContenido( base.contenedor ); 
        // Reniciamos el numero de cortes
        this.cortesActuales = 0;
        // Desactivamos la barra de progreso
        this.progresBar.setIsVisible( false );
    }

    override public void actuar( PlayerMueble pPlayer )
    {
        // Si el mueble no esta vacio
        if( !base.contenedor.isEmpty() )
        {
            // Extraemos el contenido
            GameObject contenido = base.contenedor.getContenido();
            // Si el contenido es un ingrediente
            if( contenido.TryGetComponent( out Ingrediente ingredienteCortar ) )
            {
                // Buscamos si existe alguna receta cocinable para este ingrediente
                Receta receta = this.recetasDisponibles.getRecetaCocinable( ingredienteCortar );
                // Si encontramos una receta valida, se trata de un ingrediente cortable
                if( receta != null )
                {
                    // Identificamos el ingrediente cortado
                    Ingrediente ingredienteCortado = receta.getOuput().prefab.GetComponent<Ingrediente>();
                    // Incrementamos el numero de cortes
                    this.cortesActuales++; 
                    // Hacemos avanzar la barra de progreso
                    this.progresBar.setProgreso( this.cortesActuales , receta.getProgreso() );
                    // Reproducimos la animacion
                    animador.SetBool( this.tag_animacion , true );
                    // Reproducimos el efecto de sonido
                    this.sonido.reproducirOneShot( this.listaEfectos );
                    // Si el contenido se ha cortado el numero de veces especificado
                    if( this.cortesActuales >= receta.getProgreso() )
                    {
                        // Creamos una nueva instancia del ingrediente cortado dentro del contenedor
                        base.contenedor.spawnContenido( ingredienteCortado.getIngrediente().prefab );
                        // Destruimos el ingrediente anterior
                        Destroy( contenido );
                    }
                    // En cualquier otro caso, Devolvemos el contenido
                    else{ base.contenedor.setContenido( contenido ); }
                }
                // En cualquier otro caso, Devolvemos el contenido
                else{ base.contenedor.setContenido( contenido ); }
            }
            // En cualquier otro caso, Devolvemos el contenido
            else{ base.contenedor.setContenido( contenido ); }
        }
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //


}
