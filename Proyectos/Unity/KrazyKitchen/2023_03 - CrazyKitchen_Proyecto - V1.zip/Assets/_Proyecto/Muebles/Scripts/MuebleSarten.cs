using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuebleSarten : Mueble
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

    // ---------------- Modelo ---------------- //
    private ListaRecetas recetasDisponibles;

	[Header("Cocinando")]
    [SerializeField] private UIProgresBar progresBar;
    [SerializeField] private GameObject particulas;
    [SerializeField] private GameObject fuego;

	[Header("Alerta")]
    [SerializeField] private GameObject alerta;
    [SerializeField] private float tiempoAviso = 0.2f;

	[Header("Musica")]
    [SerializeField] private float volumen = 0.2f;
    [SerializeField] private Sound sonido;
    [SerializeField] private AudioClip efectoFreir;

    // -------------- Constantes -------------- //
    private string tag_animacion = "Cut";

    // --------------- Variables -------------- //
	private float tiempoPreparacion = 0;
	
	// --------------- Atributos -------------- //

	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    override protected void inicializaciones( )
    {
        this.recetasDisponibles = this.gameObject.GetComponent<ListaRecetas>();
        desactivarAlerta();
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    public void Update()
    {
        // Si estamos jugando
        if( KitchenGameManager.Instancia.isPlaying() )
        {
            cocinando();
        }
    }

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    override public void interactuar( PlayerMueble pPlayer )
    {
        // Intercambiamos el contenido entre el Player y el Mueble
        pPlayer.intercambiarContenido( base.contenedor );
        // Desactvamos el mueble
        desactivarMueble();
        // Desactivamos la alerta
        desactivarAlerta();
    }

    private void cocinando( )
    {
        // Si el mueble no esta vacio
        if( !base.contenedor.isEmpty() )
        {
            // Extraemos el contenido
            GameObject contenido = base.contenedor.getContenido();
            // Si el contenido es un ingrediente
            if( contenido.TryGetComponent( out Ingrediente ingredienteCortar ) )
            {
                // Buscamos si existe alguna receta cocinable para este ingrediente
                Receta receta = this.recetasDisponibles.getRecetaCocinable( ingredienteCortar );
                // Si encontramos una receta valida, se trata de un ingrediente cocinable
                if( receta != null )
                {
                    // Identificamos el ingrediente cocinado
                    Ingrediente ingredienteCocinado = receta.getOuput().prefab.GetComponent<Ingrediente>();
                    // Incrementamos el tiempo de preparacion
                    this.tiempoPreparacion += Time.deltaTime;
                    // Hacemos avanzar la barra de progreso
                    this.progresBar.setProgreso( this.tiempoPreparacion , receta.getProgreso() );
                    // Activamos el mueble
                    activarMueble();
                    // Si la receta va a producir basura, Activamos la alerta
                    if( receta.isBasura() ){ activarAlerta(); }
                    // Si el contenido se ha cocinado durante el tiempo especificado
                    if( this.tiempoPreparacion >= receta.getProgreso() )
                    {
                        // Creamos una nueva instancia del ingrediente cortado dentro del contenedor
                        base.contenedor.spawnContenido( ingredienteCocinado.getIngrediente().prefab );
                        // Destruimos el ingrediente anterior
                        Destroy( contenido );
                        // Reiniciamos el temporizador
                        this.tiempoPreparacion = 0;
                        // Desactivamos la alerta
                        desactivarAlerta();
                    }
                    // En cualquier otro caso, Devolvemos el contenido
                    else{ base.contenedor.setContenido( contenido ); }
                }
                // En cualquier otro caso, 
                else
                { 
                    // Devolvemos el contenido
                    base.contenedor.setContenido( contenido );
                    // Desactvamos el mueble
                    desactivarMueble();
                    // Desactivamos la alerta
                    desactivarAlerta();
                }
            }
            // En cualquier otro caso, Devolvemos el contenido
            else
            { 
                // Devolvemos el contenido
                base.contenedor.setContenido( contenido );
                // Desactvamos el mueble
                desactivarMueble();                    
                // Desactivamos la alerta
                desactivarAlerta();
            }
        }
    }

    private void activarMueble()
    {
        // Si no esta activo
        if( !this.fuego.activeSelf )
        {
            // Activamos la sarten
            this.particulas.SetActive( true );
            this.fuego.SetActive( true );
            // Reproducimos el efecto de audio
            sonido.startReproduccion( this.efectoFreir );
        }
    }
    private void desactivarMueble()
    {
        // Reiniciamos el temporizador
        this.tiempoPreparacion = 0;
        // Desactivamos la sarten
        this.particulas.SetActive( false );
        this.fuego.SetActive( false );
        // Desactivamos la barra de progreso
        this.progresBar.setIsVisible( false );
        // Detenemos el efecto de Audio
        sonido.stopReproduccion();
    }

    private void activarAlerta(){ this.alerta?.SetActive(true); }

    private void desactivarAlerta(){ this.alerta?.SetActive(false); }


    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //


}
