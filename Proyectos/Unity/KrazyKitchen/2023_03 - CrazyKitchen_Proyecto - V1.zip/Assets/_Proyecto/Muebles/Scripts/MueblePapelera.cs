using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MueblePapelera : Mueble
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

    // -------------- Constantes -------------- //

    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	[Header("Musica")]
    [SerializeField] private Sound sonido;
    [SerializeField] private AudioClip[] listaEfectos;

	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    public override bool isIntercambioValido( Contenedor pContenedor )
    {
        // Para el mueble papelera un intercambio es valido si las manos del personaje estan llenas
        return !pContenedor.isEmpty();
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //public void Update(){}

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    override public void interactuar( PlayerMueble pPlayer )
    {
        pPlayer.deleteContenido();
        // Reproducimos el efecto de sonido
        this.sonido.reproducirOneShot( this.listaEfectos );
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //


}
