using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuebleVisuals : MonoBehaviour
{
    
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Start()
    {
        // Suscripcion al evento de interactuar del InputSystem
        InputManager.Instancia.onInteractuarAction += detectarMuebleSeleccionado;
    }

    // ######################################## //
    // ############ CAMBIAR MODELO ############ //
    // ######################################## //

    private void detectarMuebleSeleccionado( object pSender , System.EventArgs pArgs ) 
    { 
        
    }
	

}
