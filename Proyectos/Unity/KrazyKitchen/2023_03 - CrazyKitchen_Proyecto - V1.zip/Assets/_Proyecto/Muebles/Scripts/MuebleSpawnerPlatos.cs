using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuebleSpawnerPlatos : Mueble
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

    // -------------- Constantes -------------- //
	[Header("Spawn")]
    [SerializeField] private Ingrediente ingrediente;
    [SerializeField] private float tiempoSpawn;

    // --------------- Variables -------------- //

    // --------------- Atributos -------------- //

    // ----------------- Flags ---------------- //

    private bool isActiva = true;

    // --------------- Mensajes --------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    protected override void inicializaciones()
    {
        // Iniciamos el proceso de generacion de platos
        StartCoroutine( spawnPlatos() );
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    public override bool isIntercambioValido( Contenedor pContenedor )
    {
        // Para el mueble Spawner un intercambio es valido si las manos del personaje estan vacias
        return pContenedor.isEmpty();
    }
    
    // ######################################## //
    // ############## CORRUTINAS ############## //
    // ######################################## //

    private IEnumerator spawnPlatos()
    {
        while( this.isActiva )
        {
            base.contenedor.spawnContenido( this.ingrediente.getIngrediente().prefab );
            yield return new WaitForSeconds( this.tiempoSpawn );
        }
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //public void Update(){}

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    override public void interactuar( PlayerMueble pPlayer )
    {
        // Si las manos del jugador estan vacias
        if( pPlayer.isEmpty() )
        {
            // Obtenemos el contenido del contenedor
            GameObject contenido = base.contenedor.getContenido();
            // Le damos el contenido al jugador
            pPlayer.setContenido( contenido );
        }
        
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //


}
