using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuebleEntrega : Mueble
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

    // ---------------- Modelo ---------------- //

    // -------------- Constantes -------------- //

    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //public void Update(){}

    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    override public void interactuar( PlayerMueble pPlayer )
    {
        // Si el mueble esta vacio pero las manos del jugador no 
        if( base.contenedor.isEmpty() && !pPlayer.isEmpty() )
        {
            // Obtenemos el contenido del jugador
            GameObject contenido = pPlayer.getContenido();
            // Si se trata de un plato
            if( contenido.TryGetComponent( out IngredientePlato plato ) )
            {
                // Intentamos efectuar la entrega
                bool isEntregado = PlatoManager.Instancia.entregarPlato( plato.getListaIngredientes() );
                // Si la entrega ha tenido exito, Destruimos el contenido
                if( isEntregado ){ Destroy( contenido ); }
                // Si la entrega no ha tenido exito, Devolvemos el contenido al jugador
                else{ pPlayer.setContenido( contenido ); }
            }
            // Si no se trata de un plato, Devolvemos el contenido al jugador
            else{ pPlayer.setContenido( contenido ); }
        }
    }


    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //


}
