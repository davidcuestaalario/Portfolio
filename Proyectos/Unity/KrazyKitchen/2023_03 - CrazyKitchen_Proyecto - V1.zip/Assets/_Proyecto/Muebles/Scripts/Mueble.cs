using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mueble : MonoBehaviour, IMueble
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    [Header("Mueble")]
	[SerializeField] protected GameObject visualSelected;
    protected Contenedor contenedor;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    public void Start()
    {
        this.contenedor = this.gameObject.GetComponent<Contenedor>();
        inicializaciones();
    }

    virtual protected void inicializaciones( ){ }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    // -------------- Contenedor -------------- //
	public GameObject getContenido(){ return this.contenedor.getContenido(); }
    public void setContenido( GameObject pIngrediente ){ this.contenedor.setContenido( pIngrediente ); }
    public bool isEmpty(){ return this.contenedor.isEmpty(); }
    virtual public bool isIntercambioValido( Contenedor pContenedor ){ return this.contenedor.isIntercambioValido( pContenedor ); }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //public void Update(){}

    // ######################################## //
    // ################ MUEBLE ################ //
    // ######################################## //

    public void seleccionar( bool pSeleccionado )
    {
        this.visualSelected.SetActive( pSeleccionado );
    }
    
    virtual public void interactuar( PlayerMueble pPlayer )
    {
        Debug.Log("Interactuaste con " + pPlayer.name );
    }

    virtual public void actuar( PlayerMueble pPlayer )
    {
        Debug.Log("Ejecutaste la accion con " + pPlayer.name );
    }

    // ######################################## //
    // ############## CONTENEDOR ############## //
    // ######################################## //
    public void intercambiarContenido( Contenedor pContenedor ){ this.contenedor.intercambiarContenido( pContenedor ); }
    public void dropContenido( Transform pUbicacion ){ this.contenedor.dropContenido( pUbicacion ); }
    public void spawnContenido( GameObject pPrefab ){ this.contenedor.spawnContenido( pPrefab ); }
    public void deleteContenido(){ this.contenedor.deleteContenido(); }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //


}
