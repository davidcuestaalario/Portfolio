using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IMueble : IContenedor
{
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //
    abstract public void seleccionar( bool pSeleccionado );
    abstract public void interactuar( PlayerMueble pPlayer );
    abstract public void actuar( PlayerMueble pPlayer );
}
