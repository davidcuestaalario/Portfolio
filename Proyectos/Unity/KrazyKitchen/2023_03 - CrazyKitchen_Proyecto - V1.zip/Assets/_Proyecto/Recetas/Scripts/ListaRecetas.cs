using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ListaRecetas : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- // 
	[Header("Recetas Disponibles")]
    [SerializeField] private List<Receta> recetasDisponibles = new List<Receta>(); 

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    public Receta getRecetaCocinable( Ingrediente pIngrediente )
    {
        // Inicialmente no hemos encontrado ninguna Receta cocinable
        Receta recetaCocinable = null;
        // Para cada una de las Recetas disponibles
        foreach( Receta iReceta in this.recetasDisponibles )
        {  
            // Comprobamos si es cocinable
            if( iReceta.isCocinable( pIngrediente ) )
            {
                // Asignamos la receta
                recetaCocinable = iReceta;
                // Terminamos la busqueda
                break;
            }
        }
        // Devolvemos la Receta cocinable seleccionada
        return recetaCocinable;
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //void Update(){}
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //


    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
