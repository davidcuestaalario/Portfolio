using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//[CreateAssetMenu()]
public class Receta_SO : ScriptableObject
{
    public string nombre;
    public Ingrediente_SO input;
    public Ingrediente_SO ouput;
    public int progreso;
    public bool isBasura;
}
