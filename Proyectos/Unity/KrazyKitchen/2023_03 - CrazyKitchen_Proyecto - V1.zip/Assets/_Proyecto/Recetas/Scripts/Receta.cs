using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Receta : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
	
    [SerializeField] private Receta_SO receta; 

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	
	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    //void Start(){}
	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
    
    public string getNombre( ){ return this.receta.nombre; }
    public Ingrediente_SO getInput( ){ return this.receta.input; }
    public Ingrediente_SO getOuput( ){ return this.receta.ouput; }
    public int getProgreso( ){ return this.receta.progreso; }
    public bool isBasura( ){ return this.receta.isBasura; }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //void Update(){}
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    public bool isCocinable( Ingrediente pIngrediente )
    {
        // Inicialmente asumimos que la receta no sera cocinable
        bool isCocinable = false;
        // Si el ingrediente es el input de la receta, La receta sera cocinable
        if( this.receta.input.Equals( pIngrediente.getIngrediente() ) ){ isCocinable = true; }
        // Devolvemos la comprobacion
        return isCocinable;
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
