using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sound : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //
    private AudioSource fuente;
    
    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
    [SerializeField] private float volumenMultiplicador = 1f;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start()
    {
        this.fuente = this.gameObject.GetComponent<AudioSource>();
        this.fuente.volume = this.fuente.volume * this.volumenMultiplicador;
    }
    
    // ######################################## //
    // ########### GETERS Y SETERS ############ //
    // ######################################## //

    private AudioClip getRandomClip( AudioClip[] pListaEfectos )
    {
        // Seleccionamos un elemento aleatorio
        int index = Random.Range( 0 , pListaEfectos.Length );
        // Devolvemos el elemento seleccionado
        return pListaEfectos[index];
    }

    // ######################################## //
    // ############## REPRODUCIR ############## //
    // ######################################## //

    // --------- Sonidos Permanentes ---------- //
    public void startReproduccion( AudioClip pClip )
    {
        // Detiene el Clip anterior
        this.fuente.Stop();
        // Configura el nuevo Clip
        this.fuente.clip = pClip;
        // Inicia el nuevo Clip
        this.fuente.Play();
    }

    public void stopReproduccion( )
    {
        // Detiene el Clip anterior
        this.fuente.Stop();
    }
    
    // ---------- Sonidos Puntuales ----------- //
    public void reproducirOneShot( AudioClip pClip )
    {
        this.fuente.PlayOneShot( pClip );
    }

    public void reproducirOneShot( AudioClip[] pListaClips )
    {
        AudioClip clip = getRandomClip( pListaClips );
        this.fuente.PlayOneShot( clip );
    }

}
