using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

/*
 *  Dado el AudioMixer con los canales volumenMusica y volumenEfectos
 *  Permite reproducir AudioClips
 */
public class SoundManager : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //
    private AudioSource source;
    [SerializeField] private AudioMixer mixer;

    private enum Fuente { volumenMusica , volumenEfectos }
    private Fuente fuente = Fuente.volumenEfectos;
    
    // -------------- Constantes -------------- //
	private string label_Volumen = "label_VolumenEfectos";

    // --------------- Variables -------------- //
	
    [SerializeField] private float volumenMultiplicador = 1f;

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    public static SoundManager Instancia { get ; private set; }
    void Awake()
    {
        // -------------- Singelton -------------- //
        // Si ya existe una instancia y no es esta
        if( Instancia != null && Instancia != this )
        { 
            // Destruimos la instancia actual
            Destroy( this.gameObject );
        }
        // Si no existe ninguna instancia
        else
        { 
            // Inicializamos una nueva instancia
            Instancia = this;
            // Indicamos que debe conservarse entre escenas
            // DontDestroyOnLoad( this.gameObject );
        }
    }

    void Start()
    {
        this.source = this.gameObject.GetComponent<AudioSource>();
        // --------------- Volumen ---------------- //
        this.mixer.SetFloat( fuente.ToString() , cargarVolumen() );
    }

    // ######################################## //
    // ########### GETERS Y SETERS ############ //
    // ######################################## //

    private AudioClip getRandomClip( AudioClip[] pListaEfectos )
    {
        // Seleccionamos un elemento aleatorio
        int index = Random.Range( 0 , pListaEfectos.Length );
        // Devolvemos el elemento seleccionado
        return pListaEfectos[index];
    }

    public string getLabel_Volumen( ){ return this.label_Volumen; }

    // ######################################## //
    // ############## REPRODUCIR ############## //
    // ######################################## //

    // ---------- Sonidos Puntuales ----------- //
    public void reproducirOneShot( AudioClip pClip )
    {
        this.source.PlayOneShot( pClip );
    }

    public void reproducirOneShot( AudioClip[] pListaClips )
    {
        AudioClip clip = getRandomClip( pListaClips );
        this.source.PlayOneShot( clip );
    }

    public void reproducirOneShot( AudioClip pClip , Vector3 pPosition )
    {
        AudioSource.PlayClipAtPoint( pClip , pPosition );
    }

    public void reproducirOneShot( AudioClip[] pListaClips , Vector3 pPosition )
    {
        AudioClip clip = getRandomClip( pListaClips );
        AudioSource.PlayClipAtPoint( clip , pPosition );
    }

    public void reproducirOneShot( AudioClip pClip , Vector3 pPosition , float pVolumen )
    {
        AudioSource.PlayClipAtPoint( pClip , pPosition , pVolumen * volumenMultiplicador );
    }

    public void reproducirOneShot( AudioClip[] pListaClips , Vector3 pPosition , float pVolumen )
    {
        AudioClip clip = getRandomClip( pListaClips );
        AudioSource.PlayClipAtPoint( clip , pPosition , pVolumen * volumenMultiplicador );
    }

	// ######################################## //
    // ############## Base Datos ############## //
    // ######################################## //

    public void guardarVolumen( float pVolumen )
    {
        PlayerPrefs.SetFloat( this.label_Volumen , pVolumen );
        PlayerPrefs.Save();
    }

    public float cargarVolumen( )
    {
        return PlayerPrefs.GetFloat( this.label_Volumen );
    }

}