using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class MusicManager : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //
    private AudioSource source;
    [SerializeField] private AudioMixer mixer;

    private enum Fuente { volumenMusica , volumenEfectos }
    private Fuente fuente = Fuente.volumenMusica;

    // -------------- Constantes -------------- //
	
    private string label_Volumen = "label_VolumenMusica";

    // --------------- Variables -------------- //
   private int cancionActual;
   private int numeroCanciones;

	// --------------- Atributos -------------- //
    [SerializeField] private AudioClip[] canciones;

	// ----------------- Flags ---------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    public static MusicManager Instancia { get ; private set; }
    void Awake()
    {
        // -------------- Singelton -------------- //
        // Si ya existe una instancia y no es esta
        if( Instancia != null && Instancia != this )
        { 
            // Destruimos la instancia actual
            Destroy( this.gameObject );
        }
        // Si no existe ninguna instancia
        else
        { 
            // Inicializamos una nueva instancia
            Instancia = this;
            // Indicamos que debe conservarse entre escenas
            DontDestroyOnLoad( this.gameObject );
        }
    }

    void Start()
    {
	    // ---------------- Modelo ---------------- //
        this.source = this.gameObject.GetComponent<AudioSource>();
        reproducirMusica( this.seleccionarPrimera() );
        // --------------- Variables -------------- //
        this.cancionActual = 0;
        this.numeroCanciones = this.canciones.Length - 1;
        // --------------- Volumen ---------------- //
        this.mixer.SetFloat( fuente.ToString() , cargarVolumen() );
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    public void setListaReproduccion( AudioClip[] pCanciones )
    { 
        // Cambiamos la lista de reproduccion
        this.canciones = pCanciones; 
        // Iniciamos un nuevo tema
        this.reproducirMusica( this.seleccionarSiguiente() ); 
    }
	public AudioClip[] getListaReproduccion( ){ return this.canciones; }

    public string getLabel_Volumen( ){ return this.label_Volumen; }
    
    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    void Update()
    {
        // Si no se esta reproducciendo ninguna cancion
        if( !this.source.isPlaying )
        { 
            // Reproducimos la siguiente
            reproducirMusica( this.seleccionarSiguiente() ); 
        }
    }

    // ######################################## //
    // ############## REPRODUCIR ############## //
    // ######################################## //

    // Reproduce en bucle el Clip indicado por el canal volumenMusica
    public void reproducirMusica( AudioClip pMusica )
    {
        // Detiene el Clip anterior
        this.source.Stop();
        // Configura el nuevo Clip
        this.source.clip = pMusica;
        // Inicia el nuevo Clip
        this.source.Play();
    }

    // ######################################## //
    // ############# SELECCIONAR ############## //
    // ######################################## //

    public AudioClip seleccionarPrimera()
    {
        // Seleccionamos la primera cancion 
        this.cancionActual = 0;
        // Devolvemos la cancion seleccionada
        return this.canciones[ this.cancionActual ];
    }

    public AudioClip seleccionarSiguiente()
    {
        // Seleccionamos la cancion siguiente 
        this.cancionActual++;
        // Si la cancion selecionada es mayor que la ultima volvemos a la primera 
        if( this.cancionActual > this.numeroCanciones ){ this.cancionActual = 0; }
        // Devolvemos la cancion seleccionada
        return this.canciones[ this.cancionActual ];
    }

    public AudioClip seleccionarAnterior()
    {
        // Seleccionamos la cancion anterior 
        this.cancionActual--;
        // Si la cancion seleccionada es menor que la primera volvemos a la ultima
        if( this.cancionActual < 0 ){ this.cancionActual = this.numeroCanciones; }
        // Devolvemos la cancion seleccionada
        return this.canciones[ this.cancionActual ];
    }

	// ######################################## //
    // ############## Base Datos ############## //
    // ######################################## //

    public void guardarVolumen( float pVolumen )
    {
        PlayerPrefs.SetFloat( this.label_Volumen , pVolumen );
        PlayerPrefs.Save();
    }

    public float cargarVolumen( )
    {
        return PlayerPrefs.GetFloat( this.label_Volumen );
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //
}
