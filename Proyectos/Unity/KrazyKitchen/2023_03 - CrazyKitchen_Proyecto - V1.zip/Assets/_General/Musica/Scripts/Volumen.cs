using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

/*
 *  Dado el AudioMixer con los canales volumenMusica y volumenEfectos
 *  Permite modificar el volumen mediante Sliders
 *  
 *  Modo de Uso:
 *  - Asignarselo directamente a un Slider 
 */

public class Volumen : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //

	// ---------------- Modelo ---------------- //
    [SerializeField] private AudioMixer mixer;

    private enum Fuente { volumenMusica , volumenEfectos }
    [SerializeField] private Fuente fuente;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //

	// --------------- Atributos -------------- //
	
    private Slider slider;

	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    void Start()
    {
        // Inicializamos el Slider
        this.slider = this.gameObject.GetComponent<Slider>();
        this.slider.maxValue = 10;
        this.slider.minValue = 0.1f;
        // Ajustamos el valor inicial del Slider
        float volumen = cargarVolumen(); 
        this.slider.value = Mathf.Pow( 10 , ( volumen / 20 ) );
        // Añadimos un lisener para cuando cambie de valor
        this.slider.onValueChanged.AddListener( controlarVolumen );
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    private float cargarVolumen( )
    {
        // Inicializamos el volumen
        float volumen = 1f;
        // Obtenemos el volumen de la fuente correspondiente
        if( this.fuente.Equals( Fuente.volumenMusica ) ) { volumen = MusicManager.Instancia.cargarVolumen(); }
        else if( this.fuente.Equals( Fuente.volumenEfectos ) ){ volumen = SoundManager.Instancia.cargarVolumen(); }
        else{ Debug.Log( "Error cargar volumen: No coincide ninguna fuente" ); } 
        // Devolvemos el volumen obtenido
        return volumen;
    }

    private void guardarVolumen( float pVolumen )
    {
        // Cargamos el volumen en la fuente indicada
        if( this.fuente.Equals( Fuente.volumenMusica ) ) { MusicManager.Instancia.guardarVolumen( pVolumen ); }
        else if( this.fuente.Equals( Fuente.volumenEfectos ) ){ SoundManager.Instancia.guardarVolumen( pVolumen ); }
        else{ Debug.Log( "Error cargar volumen: No coincide ninguna fuente" ); } 
    }

    // ######################################## //
    // ################ VOLUMEN ############### //
    // ######################################## //

    private void controlarVolumen( )
    {
        controlarVolumen( this.slider.value );
    }

    public void controlarVolumen( float pSliderValue )
    {
        // Calculamos el volumen en escala logaritmica
        float volumen = Mathf.Log10( pSliderValue ) * 20;
        // Debug.Log("volumen = " + volumen + " Value = " + pSliderValue );
        // Seteamos el valor al AudioMixer
        this.mixer.SetFloat( fuente.ToString() , volumen );
        // Guardamos en la Base de datos el nuevo volumen
        guardarVolumen( volumen );
    }




}
