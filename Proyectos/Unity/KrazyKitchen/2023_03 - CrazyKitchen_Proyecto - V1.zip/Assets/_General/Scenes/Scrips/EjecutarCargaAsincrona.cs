using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class EjecutarCargaAsincrona : MonoBehaviour
{
    // ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
	
    // -------------- Constantes -------------- //
    private float retardo = 1f;

    // --------------- Atributos -------------- //

    [Header("Menu de Carga")]
    [SerializeField] private UIProgresPercentage barraCarga;
    [SerializeField] private TMP_Text consejoCarga;

    [Header("Consejos durante el proceso de Carga")]
    [SerializeField] private List<string> listaConsejos;
    [SerializeField] private string mensajeCargaCompletada = "Press Any key";
    
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //

    // Cuando se inicialice el componente se iniciara el proceso de carga de la escena objetivo
    void Start()
    { 
        // Seleccionamos un consejo aleatorio
        seleccionarConsejoRandom();
        // Iniciamos la carga de la escena
        Invoke( "ejecutarCargaAsincrona" , this.retardo ); 
    }

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //


    // ######################################## //
    // ############### EVENTOS ################ //
    // ######################################## //

    private void ejecutarCargaAsincrona( )
    {
        ManagerEscenas.Instancia.ejecutarCargaAsincrona( );
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
    
    void Update()
    {
        // Si se esta cargando la escena asincrona
        if( ManagerEscenas.Instancia.isCargandoEscena() )
        { 
            // Obtenemos el porcentaje de carga
            float porcentajeCarga = ManagerEscenas.Instancia.getPorcentajeCarga();
            // Actualizamos la barra de carga
            this.barraCarga.setProgreso( porcentajeCarga , 1 );
        }
        if( ManagerEscenas.Instancia.isEscenaCargada() )
        {
            this.consejoCarga.text = this.mensajeCargaCompletada;
        }
    }

    // ######################################## //
    // ############### CONSEJOS ############### //
    // ######################################## //

    private void seleccionarConsejoRandom()
    {
        // Eliminamos el consejo anterior
        this.consejoCarga.text = "";
        // Si la lista de consejos no esta vacia
        if( this.listaConsejos.Count > 0 )
        {
            // Seleccionamos un consejo aleatorio
            int index = Random.Range( 0 , this.listaConsejos.Count );
            this.consejoCarga.text = this.listaConsejos[index];
        }
    }


}
