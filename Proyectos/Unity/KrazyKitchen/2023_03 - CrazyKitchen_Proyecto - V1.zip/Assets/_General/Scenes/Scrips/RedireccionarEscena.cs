using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class RedireccionarEscena : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
		
	// ---------------- Modelo ---------------- //
    [SerializeField] private Button buttonStart;

    // -------------- Constantes -------------- //
	
    // --------------- Variables -------------- //
	[SerializeField] private List<string> kitchenLevels;
    [SerializeField] private string SelectedLevel = "";

	// --------------- Atributos -------------- //
	
	// ---------------- Flags ----------------- //
	
	// --------------- Mensajes --------------- //
	
    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
    
    void Awake()
    {
        // Inicializamos los liseners para los botones
        this.buttonStart.onClick.AddListener( startGame );
    }

	
    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //
	
    private string getRandomLevel(){ return this.kitchenLevels[ Random.Range( 0 , this.kitchenLevels.Count ) ]; }

    // ######################################## //
    // ############### EVENTOS ################ //
    // ######################################## //
    
    private void startGame()
    { 
        // Seleccionamos el nivel
        string level = this.SelectedLevel;
        if( System.String.IsNullOrEmpty( level ) ){ level = getRandomLevel(); }
        // Cargamos la escena seleccionada
        ManagerEscenas.Instancia.cargarEscenaAsincrona( level ); 
    }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //
	
	// ######################################## //
    // ################ INPUTS ################ //
    // ######################################## //
	
    // ######################################## //
    // ############## ESPECIALES ############## //
    // ######################################## //

    // ######################################## //
    // ############### VISUALES ############### //
    // ######################################## //
}
