using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class ManagerEscenas : MonoBehaviour
{
	// ######################################## //
    // ############## VARIABLES ############### //
    // ######################################## //
	
    // ---------------- Modelo ---------------- //

    [SerializeField] private string nombreEscenaCarga = "LoadingScene";

    // -------------- Constantes -------------- //
    

    // --------------- Variables -------------- //
    private string nombreEscenaObjetivo;
    private float porcentajeCarga;
    private float temporizador;

    // --------------- Atributos -------------- //

	// ----------------- Flags ---------------- //
    private bool isEscenaCarga = false;
    private bool isEscenaCargaCargada = false;
    private bool isEscenaAsincronaCargada = false;

    // ######################################## //
    // ############## CONSTRUCTOR ############# //
    // ######################################## //
	
	public static ManagerEscenas Instancia { get ; private set; }
    void Awake()
    {
        // -------------- Singelton -------------- //
        // Si ya existe una instancia y no es esta
        if( Instancia != null && Instancia != this )
        { 
            // Destruimos la instancia actual
            Destroy( this.gameObject );
        }
        // Si no existe ninguna instancia
        else
        { 
            // Inicializamos una nueva instancia
            Instancia = this;
            // Indicamos que debe conservarse entre escenas
            DontDestroyOnLoad( this.gameObject );
        }
	}

    // ######################################## //
    // ########## GETTERS Y SETTERS ########### //
    // ######################################## //

    private void setEscenaObjetivo( string pNombreEscena ){ this.nombreEscenaObjetivo = pNombreEscena; }
    public float getPorcentajeCarga(){ return this.porcentajeCarga; }
    public bool isCargandoEscena()
    { 
        // Inicialmente asumimos que no se esta cargando una escena asincrona
        bool isCargando = false;
        // Si estamos en la escena de carga y se ha iniciado el proceso de carga asincrona
        if( this.isEscenaCargaCargada && this.isEscenaCarga ){ isCargando = true; }
        // Devolvemos la comprobacion
        return isCargando; 
    }
    public bool isEscenaCargada(){ return this.isEscenaAsincronaCargada; }

    // ######################################## //
    // ################ FLUJO ################# //
    // ######################################## //

    //void Update(){}

    // ######################################## //
    // ############ CARGA DIRECTA ############# //
    // ######################################## //

    public void cargarEscenaDirecta( string pNombreEscena )
    {
        this.setEscenaObjetivo( pNombreEscena );
        SceneManager.LoadScene( this.nombreEscenaObjetivo );
    }

    // ######################################## //
    // ########### CARGA ASINCRONA ############ //
    // ######################################## //

    // Asigna la escena objetivo y carga el menu de carga
    public void cargarEscenaAsincrona( string pNombreEscena )
    {
        // Establecemos el nombre de la escena Objetivo
        this.setEscenaObjetivo( pNombreEscena );
        // Indicamos que la siguiente escena sera la de carga
        this.isEscenaCarga = true;
        // Cargamos la escena de carga
        SceneManager.LoadScene( this.nombreEscenaCarga );
    }

    // Permite al menu de carga lanzar la carga de la escena Objetivo
    public void ejecutarCargaAsincrona( )
    {
        // Indicamos que ya se ha cargado la escena de carga
        this.isEscenaCargaCargada = true;
        // Iniciamos el proceso de carga Asincrona
        StartCoroutine( procesoDeCargaAsincrona( ) );
    }

    // Corrutina que carga la escena objetivo mostrando el prgreso
    IEnumerator procesoDeCargaAsincrona( )
    {
        // Iniciamos la carga asincrona de la escenaobjetivo
        AsyncOperation cargando = SceneManager.LoadSceneAsync( this.nombreEscenaObjetivo );
        // Solicitamos confirmacion de carga
        cargando.allowSceneActivation = false;
        // Mientras el proceso de carga no halla terminado
        while( !cargando.isDone )
        {
            // Durante el proceso de carga 
            if( cargando.progress < 0.89 )
            {
                // Actualizamos los componentes de laventana de carga
                this.porcentajeCarga = cargando.progress;
            }
            // Al finalizar el proceso de carga
            else
            {
                // Actualizamos los componentes de laventana de carga
                this.porcentajeCarga = 1f;
                // Indicamos que el proceso de carga ha concluido
                this.isEscenaAsincronaCargada = true;
                // Si se pulsa cualquier tecla, Concluimos el proceso de carga
                if( Input.anyKey ){ cargando.allowSceneActivation = true; }
            }
            // Terminamos la ejecucion hasta el proximo frame
            yield return null;
        }
        // Reiniciamos el proceso de carga asincrona
        this.isEscenaCarga = false;
        this.isEscenaCargaCargada = false;
        this.isEscenaAsincronaCargada = false;
    }

    // ######################################## //
    // ################ DEBUG ################# //
    // ######################################## //

    private void printEscenaNoExiste( string pNombreEscena )
    { 
        string mensajeError = "Menu3DStart: La excena " + pNombreEscena + " No existe";
        Debug.LogError( mensajeError ); 
    }
    private void printEscenaNoExiste( int pIdEscena )
    { 
        string mensajeError = "Menu3DStart: La excena con indice " + pIdEscena + " No existe";
        Debug.LogError( mensajeError ); 
    }
         

}
